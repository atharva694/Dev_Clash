from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = "sqlite:///app.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Resume(Base):
    __tablename__ = "resumes"

    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, index=True)
    content = Column(Text)
    # Add other relevant fields as needed, e.g., analysis results

    # Example fields to store analysis results (optional, can also be done via API responses only)
    # skills = Column(Text) # Store as JSON string or comma-separated
    # ats_score = Column(Integer)

# Create tables if they don't exist
# Base.metadata.create_all(bind=engine)

# Note: The frontend spec doesn't explicitly require storing resumes in the DB.
# This model is included for completeness if you later decide to persist resumes.
# For the current spec, analysis happens on-the-fly and results are returned directly.
