# SQL schema for the 'resumes' table (if persistence is needed later)
# CREATE TABLE resumes (
#     id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
#     filename VARCHAR(255),
#     content TEXT
# );
