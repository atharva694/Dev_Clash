from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any
import sqlite3
import os
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
import numpy as np

# Database setup
DATABASE = 'app.db'

# --- Mock ML Model Setup ---
# Dummy data for training a simple model
# In a real app, this would be more sophisticated
# and potentially loaded from a file.
DUMMY_RESUME_DATA = [
    "Experienced software engineer with expertise in Python, Java, and cloud computing. Proven track record in developing scalable web applications and leading cross-functional teams. Strong skills in algorithms, data structures, and object-oriented design.",
    "Marketing specialist with 5+ years of experience in digital marketing, SEO, and social media management. Skilled in content creation, campaign management, and market analysis. Excellent communication and analytical skills.",
    "Data scientist proficient in machine learning, statistical modeling, and data visualization using Python, R, and SQL. Experience in building predictive models and deriving actionable insights from large datasets.",
    "Frontend developer focused on creating responsive and user-friendly interfaces. Expertise in HTML, CSS, JavaScript, and modern frameworks like React and Vue.js. Passionate about UI/UX design and performance optimization."
]
DUMMY_LABELS = [
    "Software Engineering",
    "Marketing",
    "Data Science",
    "Frontend Development"
]

vectorizer = TfidfVectorizer()
knn = NearestNeighbors(n_neighbors=1, algorithm='brute')
model_trained = False

def train_mock_model():
    global model_trained
    if not model_trained:
        try:
            # Train TF-IDF vectorizer
            X = vectorizer.fit_transform(DUMMY_RESUME_DATA)
            # Train KNN model
            knn.fit(X)
            model_trained = True
            print("Mock ML model trained successfully.")
        except Exception as e:
            print(f"Error training mock model: {e}")

# --- Backend Logic ---

def extract_skills(text: str) -> List[str]:
    # Basic keyword extraction for common technical skills
    skills = [
        "python", "java", "javascript", "html", "css", "react", "vue", "angular",
        "sql", "nosql", "database", "api", "rest", "graphql",
        "aws", "azure", "gcp", "docker", "kubernetes", "ci/cd",
        "machine learning", "data science", "deep learning", "ai", "nlp",
        "project management", "agile", "scrum", "communication", "leadership",
        "seo", "sem", "digital marketing", "content creation"
    ]
    found_skills = []
    text_lower = text.lower()
    for skill in skills:
        # Use regex to find whole words or common phrases
        if re.search(r'\b' + re.escape(skill) + r'\b', text_lower):
            found_skills.append(skill.capitalize())
    return list(set(found_skills))

def estimate_ats_score(text: str, skills: List[str]) -> int:
    # Very basic ATS score simulation
    # Factors: keyword density, presence of common sections (experience, education)
    score = 0
    text_lower = text.lower()
    keyword_count = sum(len(skill.lower().split()) for skill in skills)
    total_words = len(text_lower.split())

    if total_words == 0:
        return 0

    keyword_density = (keyword_count / total_words) * 100 if total_words > 0 else 0

    # Award points for common sections
    section_keywords = ["experience", "education", "skills", "projects", "achievements", "summary", "objective"]
    for keyword in section_keywords:
        if keyword in text_lower:
            score += 5

    # Add points based on keyword density (capped)
    if keyword_density > 5:
        score += min(keyword_density * 2, 30)  # Max 30 points from density
    elif keyword_density > 2:
        score += 10

    # Basic skill presence bonus
    if skills:
        score += len(skills) * 1

    # Cap score at 100
    return min(int(score), 100)

def highlight_achievements_projects(text: str) -> List[str]:
    # Simple heuristic to find potential achievements/projects
    # Look for sentences with action verbs and quantifiable results
    potential_items = []
    sentences = re.split(r'[.!?]\s+', text)
    action_verbs = ["developed", "implemented", "managed", "created", "achieved", "led", "optimized", "reduced", "increased", "designed", "built"]
    quantifiers = ["%", "$", "\d+"] # e.g., 10%, $500, 2 years

    for sentence in sentences:
        sentence_lower = sentence.lower()
        has_action_verb = any(verb in sentence_lower for verb in action_verbs)
        has_quantifier = any(re.search(q, sentence_lower) for q in quantifiers)

        if has_action_verb and has_quantifier and len(sentence.split()) > 5: # Sentence must be reasonably long
            potential_items.append(sentence.strip())
    
    # Limit to a few key items for brevity
    return potential_items[:5]

def get_suggestions(skills: List[str]) -> List[str]:
    # Basic suggestions based on skills identified
    suggestions = []
    if not skills:
        suggestions.append("Consider adding specific technical skills relevant to your target roles.")
        suggestions.append("Quantify your achievements whenever possible using numbers and data.")
        return suggestions

    if "python" in [s.lower() for s in skills] and "machine learning" not in [s.lower() for s in skills]:
        suggestions.append("Enhance your profile by mentioning specific machine learning libraries (e.g., scikit-learn, TensorFlow, PyTorch) if applicable.")
    if "javascript" in [s.lower() for s in skills] and ("react" not in [s.lower() for s in skills] and "vue" not in [s.lower() for s in skills] and "angular" not in [s.lower() for s in skills]):
        suggestions.append("Highlight experience with modern JavaScript frameworks like React, Vue, or Angular to showcase current skill relevance.")
    if len(skills) < 5:
        suggestions.append("Aim to list at least 5-10 key skills relevant to the jobs you are applying for.")
    
    suggestions.append("Use action verbs to describe your accomplishments (e.g., 'Developed', 'Managed', 'Implemented').")
    suggestions.append("Quantify achievements with metrics (e.g., 'Increased sales by 15%', 'Reduced processing time by 2 hours').")
    suggestions.append("Tailor your skills section to match keywords from job descriptions.")
    
    return list(set(suggestions))


def predict_resume_category(text: str) -> str:
    if not model_trained:
        return "Model not trained"
    try:
        text_vector = vectorizer.transform([text])
        distances, indices = knn.kneighbors(text_vector)
        predicted_label = DUMMY_LABELS[indices[0][0]]
        return predicted_label
    except Exception as e:
        print(f"Error during prediction: {e}")
        return "Prediction Error"


def analyze_resume_text(text: str) -> Dict[str, Any]:
    skills = extract_skills(text)
    ats_score = estimate_ats_score(text, skills)
    achievements = highlight_achievements_projects(text)
    suggestions = get_suggestions(skills)
    category = predict_resume_category(text)

    return {
        "skills": skills,
        "ats_score": ats_score,
        "achievements_projects": achievements,
        "suggestions": suggestions,
        "category": category
    }


# --- FastAPI App Setup ---
app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

@app.on_event("startup")
def startup_event():
    print("Running startup event...")
    # Ensure database file exists
    if not os.path.exists(DATABASE):
        print(f"Creating database file at {DATABASE}")
        conn = sqlite3.connect(DATABASE)
        conn.close()
    # Train the mock ML model on startup
    train_mock_model()
    print("Startup complete.")


@app.post("/api/analyze-resume/", response_model=Dict[str, Any])
async def analyze_resume_upload(
    file: UploadFile = File(...)
):
    """Analyzes an uploaded resume file (PDF, DOCX, TXT)."""
    content = await file.read()
    file_extension = file.filename.split('.')[-1].lower()
    text = ""

    if file_extension == 'pdf':
        try:
            import PyPDF2
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            for page in reader.pages:
                text += page.extract_text() or ""
        except ImportError:
            raise HTTPException(status_code=500, detail="PyPDF2 not installed. Cannot process PDF.")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing PDF file: {e}")
    elif file_extension == 'docx':
        try:
            import mammoth
            result = mammoth.extract_raw_text(content)
            text = result.value
        except ImportError:
            raise HTTPException(status_code=500, detail="Mammoth not installed. Cannot process DOCX.")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing DOCX file: {e}")
    elif file_extension == 'txt':
        try:
            text = content.decode('utf-8')
        except UnicodeDecodeError:
            text = content.decode('latin-1') # Fallback encoding
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error processing TXT file: {e}")
    else:
        raise HTTPException(status_code=400, detail="Unsupported file type. Please upload PDF, DOCX, or TXT.")

    if not text.strip():
        raise HTTPException(status_code=400, detail="Could not extract text from the file.")

    analysis_results = analyze_resume_text(text)
    return analysis_results

# Placeholder for potential future DB interaction if needed
# @app.get("/api/resumes/", response_model=List[SomeResumeModel])
# async def get_all_resumes():
#     # ... database query ...
#     pass

# @app.post("/api/resumes/", response_model=SomeResumeModel)
# async def upload_resume_to_db(resume_data: SomeCreateSchema):
#     # ... database insert ...
#     pass
