const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('resume-file');
const fileNameDisplay = document.getElementById('file-name');
const analyzeBtn = document.getElementById('analyze-btn');
const resultsSection = document.getElementById('results-section');
const skillsList = document.getElementById('skills-list');
const atsScoreDisplay = document.getElementById('ats-score');
const achievementsProjectsList = document.getElementById('achievements-projects-list');
const suggestionsList = document.getElementById('suggestions-list');

let uploadedFile = null;

// --- Drag and Drop Functionality ---
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('border-blue-500', 'bg-gray-800');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('border-blue-500', 'bg-gray-800');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('border-blue-500', 'bg-gray-800');
    const files = e.dataTransfer.files;
    if (files.length) {
        handleFile(files[0]);
    }
});

// --- File Input Change ---
fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) {
        handleFile(e.target.files[0]);
    }
});

// --- Analyze Button Click ---
analyzeBtn.addEventListener('click', () => {
    if (uploadedFile) {
        analyzeResume(uploadedFile);
    }
});

function handleFile(file) {
    uploadedFile = file;
    fileNameDisplay.textContent = `Selected: ${file.name}`;
    analyzeBtn.disabled = false;
    resultsSection.classList.add('hidden'); // Hide previous results
    // Clear previous results
    skillsList.innerHTML = '<li class="result-item p-3 rounded loading-text">Loading...</li>';
    atsScoreDisplay.textContent = '--';
    achievementsProjectsList.innerHTML = '<li class="result-item p-3 rounded loading-text">Loading...</li>';
    suggestionsList.innerHTML = '<li class="result-item p-3 rounded loading-text">Loading...</li>';
}

// --- Resume Analysis Logic ---
async function analyzeResume(file) {
    document.getElementById('upload-section').classList.add('hidden');
    resultsSection.classList.remove('hidden');

    let resumeText = '';
    try {
        if (file.type === 'application/pdf') {
            resumeText = await extractTextFromPDF(file);
        } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || file.name.endsWith('.doc')) { // Mammoth handles .doc as well
            resumeText = await extractTextFromDOCX(file);
        } else if (file.type === 'text/plain') {
            resumeText = await extractTextFromTXT(file);
        } else {
            throw new Error('Unsupported file type. Please upload PDF, DOCX, or TXT.');
        }

        const insights = performAnalysis(resumeText.toLowerCase()); // Basic case normalization
        displayResults(insights);

    } catch (error) {
        console.error("Error analyzing file:", error);
        skillsList.innerHTML = `<li class="result-item p-3 rounded text-red-400">Error processing file: ${error.message}</li>`;
        atsScoreDisplay.textContent = 'Error';
        achievementsProjectsList.innerHTML = `<li class="result-item p-3 rounded text-red-400">Error processing file: ${error.message}</li>`;
        suggestionsList.innerHTML = `<li class="result-item p-3 rounded text-red-400">Error processing file: ${error.message}</li>`;
    }
}

// --- Text Extraction Functions ---
async function extractTextFromPDF(file) {
    const reader = new FileReader();
    const arrayBuffer = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
    });

    const pdfjsLib = window['pdfjs-dist/build/pdf.mjs'];
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.mjs';

    const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map(item => item.str).join(' ');
        fullText += pageText + '\n';
    }
    return fullText;
}

async function extractTextFromDOCX(file) {
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value;
}

async function extractTextFromTXT(file) {
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
        reader.onload = (event) => resolve(event.target.result);
        reader.onerror = (event) => reject(new Error(`File could not be read! Code ${event.target.error.code}`));
        reader.readAsText(file);
    });
}

function performAnalysis(text) {
    // --- Placeholder Analysis ---
    // This is a highly simplified simulation. Real analysis requires NLP.
    const skills = ['JavaScript', 'React', 'Node.js', 'HTML', 'CSS', 'Python', 'SQL', 'Git', 'Problem Solving', 'Communication', 'Agile', 'RESTful APIs', 'Docker', 'Kubernetes', 'AWS', 'Azure', 'Project Management', 'Data Analysis', 'Machine Learning', 'Deep Learning'];
    const foundSkills = skills.filter(skill => text.includes(skill.toLowerCase()));
    const missingSkills = skills.filter(skill => !foundSkills.includes(skill));

    // Simulate ATS score based on presence of keywords and some basic formatting checks (very rough)
    let atsScore = 50;
    if (foundSkills.length >= 5) atsScore += 20;
    if (text.length > 500) atsScore += 10;
    if (text.includes('project') || text.includes('achievement')) atsScore += 10;
    if (text.includes('education') && text.includes('degree')) atsScore += 5;
    // Bonus for using bullet points (simulated by counting newline characters after a bullet-like marker)
    const bulletPointCount = (text.match(/^\s*[-*•]\s/gm) || []).length;
    if (bulletPointCount > 5) atsScore += 5;
    atsScore = Math.min(atsScore, 100); // Cap at 100

    // Simulate achievements/projects (look for keywords and structure)
    const achievements = text.match(/\b(achieved|completed|developed|launched|managed|led|created|designed|implemented)\b.*?(\.|;)/g) || [];
    const projects = text.match(/\b(project|initiative|system|platform|application|software)\b.*?(\.|;)/g) || [];
    // Filter out very short or likely non-relevant matches
    const relevantAchievementsProjects = [...achievements, ...projects].filter(item => item.length > 15).slice(0, 7); // Limit to 7

    // Suggestions
    const suggestions = [];
    if (missingSkills.length > 0) {
        suggestions.push(`Consider adding keywords related to these skills: <span class="highlight">${missingSkills.join(', ')}</span>.`);
    }
    if (foundSkills.length < 5) {
        suggestions.push("Ensure your key technical and soft skills are prominently listed and described, using relevant keywords.");
    }
    if (relevantAchievementsProjects.length < 3) {
        suggestions.push("Quantify your achievements and detail your projects with specific outcomes and metrics where possible.");
    }
    if (!text.includes('keywords')) {
         suggestions.push("Tailor your resume with keywords relevant to the specific job description you are applying for.");
    }
    suggestions.push("Use strong action verbs to start bullet points describing your experience and accomplishments.");
    suggestions.push("Ensure consistent formatting and clear section headings for better ATS compatibility and readability.");
    if (bulletPointCount < 3) {
        suggestions.push("Utilize bullet points to describe responsibilities and achievements, making your resume easier to scan.");
    }

    return {
        foundSkills: foundSkills,
        missingSkills: missingSkills,
        atsScore: atsScore,
        achievementsProjects: relevantAchievementsProjects,
        suggestions: suggestions
    };
}

function displayResults(insights) {
    // Skills
    skillsList.innerHTML = '';
    if (insights.foundSkills.length > 0) {
        insights.foundSkills.forEach(skill => {
            const li = document.createElement('li');
            li.className = 'result-item p-3 rounded';
            li.innerHTML = `<span class="highlight font-semibold">${skill}</span>`;
            skillsList.appendChild(li);
        });
    } else {
         skillsList.innerHTML = '<li class="result-item p-3 rounded">No specific skills detected from the predefined list.</li>';
    }
    if (insights.missingSkills.length > 0) {
         const li = document.createElement('li');
         li.className = 'result-item p-3 rounded';
         li.innerHTML = `Potential areas to strengthen: <span class="suggest">${insights.missingSkills.join(', ')}</span>`;
         skillsList.appendChild(li);
    }

    // ATS Score
    atsScoreDisplay.textContent = insights.atsScore;
    // Adjust color based on score for visual feedback
    if (insights.atsScore < 60) {
        atsScoreDisplay.classList.add('text-red-400');
        atsScoreDisplay.classList.remove('text-yellow-400', 'text-green-400');
    } else if (insights.atsScore < 85) {
        atsScoreDisplay.classList.add('text-yellow-400');
        atsScoreDisplay.classList.remove('text-red-400', 'text-green-400');
    } else {
        atsScoreDisplay.classList.add('text-green-400');
        atsScoreDisplay.classList.remove('text-red-400', 'text-yellow-400');
    }

    // Achievements & Projects
    achievementsProjectsList.innerHTML = '';
    if (insights.achievementsProjects.length > 0) {
        insights.achievementsProjects.forEach(item => {
            const li = document.createElement('li');
            li.className = 'result-item p-3 rounded';
            li.innerHTML = item.trim(); // Use innerHTML here to preserve potential HTML entities from extraction
            achievementsProjectsList.appendChild(li);
        });
    } else {
        achievementsProjectsList.innerHTML = '<li class="result-item p-3 rounded">No specific achievements or projects highlighted in the text.</li>';
    }

    // Suggestions
    suggestionsList.innerHTML = '';
    if (insights.suggestions.length > 0) {
        insights.suggestions.forEach(suggestion => {
            const li = document.createElement('li');
            li.className = 'result-item p-3 rounded';
            li.innerHTML = suggestion;
            suggestionsList.appendChild(li);
        });
    } else {
        suggestionsList.innerHTML = '<li class="result-item p-3 rounded">No specific suggestions generated.</li>';
    }
}

// Initialize UI state
analyzeBtn.disabled = true;