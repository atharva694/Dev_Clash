# Generated Full-Stack App

## Setup
1. Install dependencies: pip install -r requirements.txt
2. Run the application: python main.py
3. The server will start at http://127.0.0.1:8000. Use the /api/analyze endpoint for POST requests containing email content.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
