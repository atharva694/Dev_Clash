const SPAM_KEYWORDS = {
  'urgent': 15, 'winner': 20, 'congratulations': 15, 'free': 10, 'click here': 20, 
  'guaranteed': 12, 'no cost': 10, 'investment': 15, 'cryptocurrency': 18, 
  'account suspended': 25, 'verify identity': 20, 'unusual activity': 15, 
  'billion dollars': 22, 'inheritance': 20, 'refund': 12, 'gift card': 15,
  'lottery': 20, 'casino': 15, 'act now': 15, 'limited time': 10, 'password': 12,
  'paypal': 10, 'bank': 10, 'update your info': 18, 'claims': 15, 'weight loss': 15,
  'medicine': 10, 'viagra': 25, 'rolex': 15, 'cheap': 10, 'low price': 12
};

const analyzeBtn = document.getElementById('analyzeBtn');
const emailInput = document.getElementById('emailInput');
const gaugeProgress = document.getElementById('gaugeProgress');
const scoreValue = document.getElementById('scoreValue');
const scoreLabel = document.getElementById('scoreLabel');
const findingsContainer = document.getElementById('findingsContainer');
const spinner = document.getElementById('spinner');
const btnText = document.getElementById('btnText');
const charCount = document.getElementById('charCount');
const threatCountDisplay = document.getElementById('threatCount');

// Track character count
emailInput.addEventListener('input', (e) => {
  charCount.textContent = `${e.target.value.length} chars`;
});

function updateGauge(percent) {
  const circumference = 2 * Math.PI * 42;
  const offset = circumference - (percent / 100) * circumference;
  gaugeProgress.style.strokeDashoffset = offset;
  
  // Clear existing color classes
  gaugeProgress.classList.remove('text-blue-500', 'text-green-500', 'text-yellow-500', 'text-red-500');
  scoreLabel.classList.remove('text-green-500', 'text-yellow-500', 'text-red-500');

  if (percent > 70) {
    gaugeProgress.classList.add('text-red-500');
    scoreLabel.textContent = 'High Risk';
    scoreLabel.classList.add('text-red-500');
  } else if (percent > 35) {
    gaugeProgress.classList.add('text-yellow-500');
    scoreLabel.textContent = 'Suspicious';
    scoreLabel.classList.add('text-yellow-500');
  } else if (percent > 0) {
    gaugeProgress.classList.add('text-green-500');
    scoreLabel.textContent = 'Likely Safe';
    scoreLabel.classList.add('text-green-500');
  } else {
    gaugeProgress.classList.add('text-blue-500');
    scoreLabel.textContent = 'Clear';
  }
}

analyzeBtn.addEventListener('click', () => {
  const text = emailInput.value.toLowerCase();
  if (!text.trim()) {
    alert('Please enter email content for analysis.');
    return;
  }

  // UI State: Loading
  btnText.innerText = 'Analyzing Heuristics...';
  analyzeBtn.disabled = true;
  spinner.classList.remove('hidden');

  setTimeout(() => {
    let score = 0;
    let detected = [];

    // 1. Keyword analysis
    Object.keys(SPAM_KEYWORDS).forEach(keyword => {
      const regex = new RegExp("\\b" + keyword + "\\b", "gi");
      const matches = text.match(regex);
      if (matches) {
        score += SPAM_KEYWORDS[keyword] * Math.min(matches.length, 2); // Cap repetitive keyword weight
        detected.push({ name: keyword, type: 'Pattern Match' });
      }
    });

    // 2. Excessive capitalization check
    const capsCount = (emailInput.value.match(/[A-Z]/g) || []).length;
    if (capsCount > emailInput.value.length * 0.25 && emailInput.value.length > 30) {
      score += 20;
      detected.push({ name: 'Excessive Caps', type: 'Aggressive Formatting' });
    }

    // 3. Link density check
    const linkCount = (text.match(/http|www|\.com|\.net|\.org/g) || []).length;
    if (linkCount > 3) {
      score += 15;
      detected.push({ name: 'High Link Density', type: 'Phishing Risk' });
    }

    const finalScore = Math.min(score, 100);
    
    // Update UI
    scoreValue.textContent = `${finalScore}%`;
    updateGauge(finalScore);
    threatCountDisplay.textContent = `${detected.length} Triggers`;

    findingsContainer.innerHTML = '';
    if (detected.length === 0) {
      findingsContainer.innerHTML = `
        <div class="flex flex-col items-center justify-center py-10 text-green-400">
          <svg class="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg>
          <p class="text-xs font-bold uppercase">No threats detected</p>
        </div>`;
    } else {
      detected.forEach(item => {
        const div = document.createElement('div');
        div.className = 'bg-slate-800/40 p-3 rounded-lg border border-slate-700/50 flex justify-between items-start';
        div.innerHTML = `
          <div>
            <div class="text-[10px] text-slate-500 uppercase font-bold mb-0.5">${item.type}</div>
            <div class="text-sm text-slate-200 capitalize">${item.name}</div>
          </div>
          <div class="text-[10px] px-2 py-1 bg-red-500/10 text-red-400 rounded border border-red-500/20">Flagged</div>
        `;
        findingsContainer.appendChild(div);
      });
    }

    btnText.innerText = 'Run Heuristic Scan';
    analyzeBtn.disabled = false;
    spinner.classList.add('hidden');
  }, 1200);
});