import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from datetime import datetime

import models
from models import SessionLocal, engine, EmailScan

# Create tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="SpamShield AI API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Simple ML Model --- 
# In a real app, this would be pre-trained and loaded.
# Here we train a quick mock model on startup.
SPAM_DATA = [
    ("Get free money now winner winner winner", "spam"),
    ("Urgent account suspended verify identity investment cryptocurrency", "spam"),
    ("Meeting scheduled for tomorrow at 10am", "safe"),
    ("Lunch tomorrow? I will be there", "safe"),
    ("Claim your inheritance and refund immediately", "spam"),
    ("Project update and feedback requested", "safe"),
    ("Congratulations you have won a gift card", "spam"),
    ("The report is attached for your review", "safe"),
    ("Viagra cheap weight loss medicine fast delivery", "spam"),
    ("Can we reschedule our sync?", "safe")
]

texts = [d[0] for d in SPAM_DATA]
labels = [d[1] for d in SPAM_DATA]

vectorizer = CountVectorizer(stop_words='english')
X = vectorizer.fit_transform(texts)
clf = MultinomialNB()
clf.fit(X, labels)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- API Models ---
from pydantic import BaseModel

class EmailAnalysisRequest(BaseModel):
    content: str

class EmailAnalysisResponse(BaseModel):
    id: int
    score: float
    label: str
    triggers: List[str]
    timestamp: datetime

# --- Routes ---

@app.post("/api/analyze", response_model=EmailAnalysisResponse)
async def analyze_email(request: EmailAnalysisRequest, db: Session = Depends(get_db)):
    if not request.content.strip():
        raise HTTPException(status_code=400, detail="Empty content")

    # Use ML model for prediction
    vec_text = vectorizer.transform([request.content.lower()])
    probabilities = clf.predict_proba(vec_text)[0]
    # Get index for 'spam' class
    spam_idx = list(clf.classes_).index('spam')
    spam_prob = round(probabilities[spam_idx] * 100, 2)

    # Keyword Heuristics for the UI triggers
    SPAM_KEYWORDS = [
        'urgent', 'winner', 'congratulations', 'free', 'click here', 
        'guaranteed', 'no cost', 'investment', 'cryptocurrency', 
        'account suspended', 'verify identity', 'unusual activity', 
        'billion dollars', 'inheritance', 'refund', 'gift card',
        'lottery', 'casino', 'act now', 'limited time', 'password',
        'paypal', 'bank', 'update your info', 'claims', 'weight loss',
        'medicine', 'viagra', 'rolex', 'cheap', 'low price'
    ]
    
    detected_triggers = []
    for keyword in SPAM_KEYWORDS:
        if keyword in request.content.lower():
            detected_triggers.append(keyword.capitalize())

    # Determine Label
    if spam_prob > 70:
        label = "High Risk"
    elif spam_prob > 35:
        label = "Suspicious"
    else:
        label = "Likely Safe"

    # Save to DB
    db_scan = EmailScan(
        content=request.content,
        score=spam_prob,
        label=label,
        triggers=", ".join(detected_triggers)
    )
    db.add(db_scan)
    db.commit()
    db.refresh(db_scan)

    return {
        "id": db_scan.id,
        "score": db_scan.score,
        "label": db_scan.label,
        "triggers": detected_triggers,
        "timestamp": db_scan.created_at
    }

@app.get("/api/history", response_model=List[EmailAnalysisResponse])
async def get_history(db: Session = Depends(get_db)):
    scans = db.query(EmailScan).order_by(EmailScan.created_at.desc()).limit(10).all()
    results = []
    for s in scans:
        results.append({
            "id": s.id,
            "score": s.score,
            "label": s.label,
            "triggers": s.triggers.split(", ") if s.triggers else [],
            "timestamp": s.created_at
        })
    return results

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)