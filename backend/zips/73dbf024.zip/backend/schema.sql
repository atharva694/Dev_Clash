CREATE TABLE email_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT,
    score FLOAT,
    label VARCHAR(50),
    triggers TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);