const ctx = document.getElementById('usageChart').getContext('2d');
const usageChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'API Requests',
            data: [120, 190, 300, 500, 200, 350],
            borderColor: '#3b82f6',
            fill: false,
            tension: 0.4
        }, {
            label: 'API Errors',
            data: [5, 8, 12, 15, 10, 18],
            borderColor: '#ef4444',
            fill: false,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'API Usage Trends',
                color: '#ffffff',
                font: {
                    size: 18
                }
            },
            tooltip: {
                backgroundColor: 'rgba(31, 41, 55, 0.9)',
                titleColor: '#ffffff',
                bodyColor: '#d1d5db',
                borderColor: '#4b5563',
                borderWidth: 1
            }
        },
        scales: {
            x: {
                ticks: {
                    color: '#d1d5db'
                },
                grid: {
                    color: 'rgba(75, 85, 99, 0.5)'
                }
            },
            y: {
                ticks: {
                    color: '#d1d5db'
                },
                grid: {
                    color: 'rgba(75, 85, 99, 0.5)'
                }
            }
        }
    }
});

document.getElementById('generateReportBtn').addEventListener('click', () => {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const reportResultDiv = document.getElementById('reportResult');

    if (!startDate || !endDate) {
        reportResultDiv.textContent = 'Please select both start and end dates.';
        reportResultDiv.style.color = '#ef4444';
        return;
    }

    reportResultDiv.textContent = `Generating report from ${startDate} to ${endDate}...`;
    reportResultDiv.style.color = '#60a5fa';

    // Simulate report generation
    setTimeout(() => {
        reportResultDiv.textContent = `Report for ${startDate} to ${endDate} generated successfully. (Dummy Data)`;
        reportResultDiv.style.color = '#10b981';
        // In a real application, you would fetch data or generate a file here
    }, 1500);
});
