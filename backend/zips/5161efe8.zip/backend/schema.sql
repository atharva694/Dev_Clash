CREATE TABLE api_stats (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    timestamp DATE UNIQUE,
    requests INTEGER,
    errors INTEGER,
    usage_percentage FLOAT,
    remaining_limits INTEGER
);
CREATE INDEX ix_api_stats_id ON api_stats (id);
CREATE INDEX ix_api_stats_timestamp ON api_stats (timestamp);
