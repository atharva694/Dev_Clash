from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, Date
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime
import random

# --- Database Setup ---
DATABASE_URL = "sqlite:///./app.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# --- SQLAlchemy Models ---
class APIStat(Base):
    __tablename__ = "api_stats"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(Date, unique=True, index=True)
    requests = Column(Integer)
    errors = Column(Integer)
    usage_percentage = Column(Float)
    remaining_limits = Column(Integer)


# Create tables if they don't exist
Base.metadata.create_all(bind=engine)

# --- Pydantic Models ---
class APIStatCreate(BaseModel):
    timestamp: str
    requests: int
    errors: int
    usage_percentage: float
    remaining_limits: int

class APIStatResponse(BaseModel):
    timestamp: str
    requests: int
    errors: int
    usage_percentage: float
    remaining_limits: int

class ReportData(BaseModel):
    startDate: str
    endDate: str

class ReportResponse(BaseModel):
    message: str
    data: list | None = None

# --- FastAPI App ---
app = FastAPI()

# --- CORS Middleware ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Helper Functions ---
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def populate_dummy_data():
    db = next(get_db())
    if db.query(APIStat).count() == 0:
        print("Populating dummy data...")
        for i in range(30):
            date_str = f"2023-10-{i+1:02d}"
            stat = APIStat(
                timestamp=datetime.strptime(date_str, '%Y-%m-%d').date(),
                requests=random.randint(100, 1000),
                errors=random.randint(1, 20),
                usage_percentage=random.uniform(10.0, 90.0),
                remaining_limits=random.randint(500, 2000)
            )
            db.add(stat)
        db.commit()
        print("Dummy data populated.")

# Populate data on startup
populate_dummy_data()

# --- API Endpoints ---
@app.get("/api/stats/summary", response_model=dict)
def get_summary_stats():
    db = next(get_db())
    # Fetch latest stat for summary
    latest_stat = db.query(APIStat).order_by(APIStat.timestamp.desc()).first()

    if not latest_stat:
        raise HTTPException(status_code=404, detail="No stats found. Populate some data.")

    # Calculate average error rate for last 24 hours (or last entry if not enough data)
    recent_stats = db.query(APIStat).order_by(APIStat.timestamp.desc()).limit(2).all() # Get last 2 entries to simulate last 24h
    error_percentage = (sum(s.errors for s in recent_stats) / sum(s.requests for s in recent_stats) * 100) if recent_stats and sum(s.requests for s in recent_stats) > 0 else 0

    # Simulate request rate per minute (based on the latest entry's requests)
    request_rate_per_minute = latest_stat.requests / 60 if latest_stat.requests else 0

    return {
        "current_usage_percentage": round(latest_stat.usage_percentage, 2),
        "remaining_limits": latest_stat.remaining_limits,
        "request_rate_per_minute": round(request_rate_per_minute, 2),
        "error_percentage_last_24h": round(error_percentage, 2)
    }

@app.get("/api/stats/trend", response_model=list[APIStatResponse])
def get_usage_trend():
    db = next(get_db())
    # Fetch last 6 months of data for the chart
    # Assuming timestamps are daily, we'll take the last 30 days for a decent trend
    stats = db.query(APIStat).order_by(APIStat.timestamp.desc()).limit(30).all()
    # Reverse to show chronological order for chart
    return [APIStatResponse(
        timestamp=stat.timestamp.strftime('%Y-%m-%d'),
        requests=stat.requests,
        errors=stat.errors,
        usage_percentage=stat.usage_percentage,
        remaining_limits=stat.remaining_limits
    ) for stat in reversed(stats)]

@app.post("/api/reports", response_model=ReportResponse)
def generate_report(report_data: ReportData):
    db = next(get_db())
    try:
        start_date = datetime.strptime(report_data.startDate, '%Y-%m-%d').date()
        end_date = datetime.strptime(report_data.endDate, '%Y-%m-%d').date()
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD.")

    if start_date > end_date:
        raise HTTPException(status_code=400, detail="Start date cannot be after end date.")

    # Fetch data within the date range
    report_stats = db.query(APIStat)
    .filter(APIStat.timestamp >= start_date, APIStat.timestamp <= end_date)
    .order_by(APIStat.timestamp)
    .all()

    if not report_stats:
        return ReportResponse(message=f"No data available for the period {report_data.startDate} to {report_data.endDate}.")

    # Example: Calculate average requests and errors for the report period
    total_requests = sum(s.requests for s in report_stats)
    total_errors = sum(s.errors for s in report_stats)
    avg_requests = total_requests / len(report_stats)
    avg_errors = total_errors / len(report_stats)
    avg_usage = sum(s.usage_percentage for s in report_stats) / len(report_stats)

    report_summary = [
        {
            "date": s.timestamp.strftime('%Y-%m-%d'),
            "requests": s.requests,
            "errors": s.errors,
            "usage_percentage": round(s.usage_percentage, 2),
            "remaining_limits": s.remaining_limits
        } for s in report_stats
    ]

    return ReportResponse(
        message=f"Report generated successfully for {report_data.startDate} to {report_data.endDate}.",
        data=report_summary
    )

# --- HTML Endpoint ---
from fastapi.responses import HTMLResponse
import os

@app.get("/", response_class=HTMLResponse)
def read_root():
    # Assuming index.html is in the same directory or a 'templates' subdirectory
    # For simplicity, we'll include the HTML directly in the response.
    # In a real app, you'd use `StaticFiles` or `Jinja2Templates`.
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Usage Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Ensure Tailwind CSS respects dark mode if you had it configured, though not strictly needed here.
        // Tailwind's default is light, but we are overriding with dark styles.
    </script>
</head>
<body class="bg-gray-900 text-white font-sans">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-6">API Usage Dashboard</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-gray-800 p-5 rounded-lg shadow-md" title="Percentage of your API call limit that has been consumed.">
                <h3 class="text-lg font-semibold mb-3">Current Usage</h3>
                <p class="text-4xl font-bold" id="currentUsage">--%</p>
                <div class="w-full bg-gray-700 rounded-full h-2.5 mt-3">
                    <div class="bg-blue-500 h-2.5 rounded-full" id="currentUsageBar" style="width: 0%;"></div>
                </div>
            </div>
            <div class="bg-gray-800 p-5 rounded-lg shadow-md" title="Total number of API requests remaining for the current period.">
                <h3 class="text-lg font-semibold mb-3">Remaining Limits</h3>
                <p class="text-4xl font-bold" id="remainingLimits">--</p>
                <p class="text-sm text-gray-400">Requests per day</p>
            </div>
            <div class="bg-gray-800 p-5 rounded-lg shadow-md" title="Average rate of API requests per minute over the last hour.">
                <h3 class="text-lg font-semibold mb-3">Request Rate</h3>
                <p class="text-4xl font-bold" id="requestRate">--/min</p>
                <p class="text-sm text-gray-400">Avg. last hour</p>
            </div>
            <div class="bg-gray-800 p-5 rounded-lg shadow-md" title="Percentage of API requests that resulted in an error in the last 24 hours.">
                <h3 class="text-lg font-semibold mb-3">Errors</h3>
                <p class="text-4xl font-bold" id="errorPercentage">--%</p>
                <p class="text-sm text-gray-400">Last 24 hours</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 class="text-xl font-semibold mb-4">API Usage Trends</h3>
                <div style="height: 300px;">
                    <canvas id="usageChart"></canvas>
                </div>
            </div>
            <div class="bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 class="text-xl font-semibold mb-4">Generate Report</h3>
                <div class="mb-4">
                    <label for="startDate" class="block text-sm font-medium text-gray-300">Start Date</label>
                    <input type="date" id="startDate" class="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2">
                </div>
                <div class="mb-4">
                    <label for="endDate" class="block text-sm font-medium text-gray-300">End Date</label>
                    <input type="date" id="endDate" class="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2">
                </div>
                <button id="generateReportBtn" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-800">Generate Report</button>
                <div id="reportResult" class="mt-4 text-sm text-gray-400 min-h-[100px]"></div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // --- Chart Configuration ---
        const ctx = document.getElementById('usageChart').getContext('2d');
        let usageChartInstance = null; // Initialize to null

        function updateChart(labels, dataRequests, dataErrors) {
            if (usageChartInstance) {
                usageChartInstance.destroy(); // Destroy previous chart if it exists
            }
            usageChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'API Requests',
                        data: dataRequests,
                        borderColor: '#3b82f6',
                        fill: false,
                        tension: 0.4
                    }, {
                        label: 'API Errors',
                        data: dataErrors,
                        borderColor: '#ef4444',
                        fill: false,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'API Usage Trends',
                            color: '#ffffff',
                            font: {
                                size: 18
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(31, 41, 55, 0.9)',
                            titleColor: '#ffffff',
                            bodyColor: '#d1d5db',
                            borderColor: '#4b5563',
                            borderWidth: 1
                        }
                    },
                    scales: {
                        x: {
                            ticks: {
                                color: '#d1d5db'
                            },
                            grid: {
                                color: 'rgba(75, 85, 99, 0.5)'
                            }
                        },
                        y: {
                            ticks: {
                                color: '#d1d5db'
                            },
                            grid: {
                                color: 'rgba(75, 85, 99, 0.5)'
                            }
                        }
                    }
                }
            });
        }

        // --- Fetch Data and Update UI ---
        async function fetchData() {
            try {
                // Fetch Summary Stats
                const summaryResponse = await fetch('/api/stats/summary');
                if (!summaryResponse.ok) throw new Error(`HTTP error! status: ${summaryResponse.status}`);
                const summaryData = await summaryResponse.json();

                document.getElementById('currentUsage').textContent = `${summaryData.current_usage_percentage}%`;
                document.getElementById('currentUsageBar').style.width = `${summaryData.current_usage_percentage}%`;
                document.getElementById('remainingLimits').textContent = summaryData.remaining_limits;
                document.getElementById('requestRate').textContent = `${summaryData.request_rate_per_minute}/min`;
                document.getElementById('errorPercentage').textContent = `${summaryData.error_percentage_last_24h}%`;

                // Fetch Trend Data for Chart
                const trendResponse = await fetch('/api/stats/trend');
                if (!trendResponse.ok) throw new Error(`HTTP error! status: ${trendResponse.status}`);
                const trendData = await trendResponse.json();

                const labels = trendData.map(item => item.timestamp);
                const dataRequests = trendData.map(item => item.requests);
                const dataErrors = trendData.map(item => item.errors);

                updateChart(labels, dataRequests, dataErrors);

            } catch (error) {
                console.error('Error fetching data:', error);
                // Display error message to user if needed
                document.getElementById('currentUsage').textContent = 'Error';
                document.getElementById('remainingLimits').textContent = 'Error';
                document.getElementById('requestRate').textContent = 'Error';
                document.getElementById('errorPercentage').textContent = 'Error';
                if (usageChartInstance) usageChartInstance.destroy(); // Clear chart on error
            }
        }

        // --- Event Listeners ---
        document.getElementById('generateReportBtn').addEventListener('click', async () => {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            const reportResultDiv = document.getElementById('reportResult');

            if (!startDate || !endDate) {
                reportResultDiv.textContent = 'Please select both start and end dates.';
                reportResultDiv.style.color = '#ef4444';
                return;
            }

            reportResultDiv.textContent = `Generating report from ${startDate} to ${endDate}...`;
            reportResultDiv.style.color = '#60a5fa';

            try {
                const response = await fetch('/api/reports', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ startDate, endDate })
                });

                const result = await response.json();

                if (!response.ok) {
                    throw new Error(result.detail || `HTTP error! status: ${response.status}`);
                }

                reportResultDiv.textContent = result.message;
                reportResultDiv.style.color = '#10b981'; // Green for success

                // Optionally display report data if available
                if (result.data && result.data.length > 0) {
                    let dataStr = "\nDetails:\n";
                    result.data.forEach(item => {
                        dataStr += `- Date: ${item.date}, Req: ${item.requests}, Err: ${item.errors}, Usage: ${item.usage_percentage}%, Limits: ${item.remaining_limits}\n`;
                    });
                    reportResultDiv.textContent += dataStr;
                }

            } catch (error) {
                console.error('Report generation error:', error);
                reportResultDiv.textContent = `Error: ${error.message}`;
                reportResultDiv.style.color = '#ef4444'; // Red for error
            }
        });

        // --- Initial Data Load ---
        document.addEventListener('DOMContentLoaded', fetchData);

    </script>
</body>
</html>
    "
    return HTMLResponse(content=html_content)
