from sqlalchemy import Column, Integer, String, Float, Date
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class APIStat(Base):
    __tablename__ = "api_stats"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(Date, unique=True, index=True)
    requests = Column(Integer)
    errors = Column(Integer)
    usage_percentage = Column(Float)
    remaining_limits = Column(Integer)
