# Generated Full-Stack App

## Setup
1. Save the backend code as `main.py`.
2. Install dependencies: `pip install -r requirements.txt` (create requirements.txt with the content provided).
3. Run the FastAPI server: `uvicorn main:app --reload`
4. Open your browser to `http://127.0.0.1:8000/` to access the dashboard.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
