from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from database import SessionLocal, engine, Base
from models import Restaurant, MenuItem, Order, Booking

app = FastAPI()

app.add_middleware( 
    CORSMiddleware,
    allow_origins=["*"]
)

# Create database tables
Base.metadata.create_all(bind=engine)

# --- Pydantic Models for Request/Response ---
class MenuItemCreate(BaseModel):
    name: str
    description: str
    price: float
    restaurant_id: int

class MenuItemResponse(MenuItemCreate):
    id: int

class RestaurantCreate(BaseModel):
    name: str
    address: str
    cuisine_type: str
    phone_number: str

class RestaurantResponse(RestaurantCreate):
    id: int
    menu_items: List[MenuItemResponse] = []

class OrderCreate(BaseModel):
    user_id: int
    restaurant_id: int
    items: List[dict] # item_id, quantity, price
    total_amount: float
    status: str = "Pending"

class OrderResponse(OrderCreate):
    id: int

class BookingCreate(BaseModel):
    user_id: int
    restaurant_id: int
    booking_time: str
    num_people: int
    status: str = "Confirmed"

class BookingResponse(BookingCreate):
    id: int

# --- API Endpoints ---

# Restaurants
@app.post("/api/restaurants", response_model=RestaurantResponse, status_code=201)
def create_restaurant(restaurant: RestaurantCreate):
    db = SessionLocal()
    db_restaurant = Restaurant(**restaurant.dict())
    db.add(db_restaurant)
    db.commit()
    db.refresh(db_restaurant)
    db.close()
    return db_restaurant

@app.get("/api/restaurants", response_model=List[RestaurantResponse])
def get_restaurants():
    db = SessionLocal()
    db_restaurants = db.query(Restaurant).all()
    db.close()
    # Manually construct response to include menu_items (simplified for this example)
    # In a real app, you'd likely fetch these or have a relationship loaded
    restaurants_data = []
    for r in db_restaurants:
        restaurants_data.append(RestaurantResponse(id=r.id, name=r.name, address=r.address, cuisine_type=r.cuisine_type, phone_number=r.phone_number, menu_items=[]))
    return restaurants_data

@app.get("/api/restaurants/{restaurant_id}", response_model=RestaurantResponse)
def get_restaurant_by_id(restaurant_id: int):
    db = SessionLocal()
    db_restaurant = db.query(Restaurant).filter(Restaurant.id == restaurant_id).first()
    db.close()
    if not db_restaurant:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    # Manually construct response to include menu_items (simplified)
    return RestaurantResponse(id=db_restaurant.id, name=db_restaurant.name, address=db_restaurant.address, cuisine_type=db_restaurant.cuisine_type, phone_number=db_restaurant.phone_number, menu_items=[])

# Menu Items
@app.post("/api/restaurants/{restaurant_id}/menu", response_model=MenuItemResponse, status_code=201)
def create_menu_item(restaurant_id: int, item: MenuItemCreate):
    # Ensure the item belongs to the correct restaurant
    if item.restaurant_id != restaurant_id:
        raise HTTPException(status_code=400, detail="Restaurant ID mismatch")
    db = SessionLocal()
    db_item = MenuItem(**item.dict())
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    db.close()
    return db_item

@app.get("/api/restaurants/{restaurant_id}/menu", response_model=List[MenuItemResponse])
def get_menu_items(restaurant_id: int):
    db = SessionLocal()
    db_items = db.query(MenuItem).filter(MenuItem.restaurant_id == restaurant_id).all()
    db.close()
    return db_items

# Orders
@app.post("/api/orders", response_model=OrderResponse, status_code=201)
def create_order(order: OrderCreate):
    db = SessionLocal()
    db_order = Order(**order.dict())
    db.add(db_order)
    db.commit()
    db.refresh(db_order)
    db.close()
    return db_order

@app.get("/api/orders", response_model=List[OrderResponse])
def get_orders():
    db = SessionLocal()
    db_orders = db.query(Order).all()
    db.close()
    return db_orders

# Bookings
@app.post("/api/bookings", response_model=BookingResponse, status_code=201)
def create_booking(booking: BookingCreate):
    db = SessionLocal()
    db_booking = Booking(**booking.dict())
    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    db.close()
    return db_booking

@app.get("/api/bookings", response_model=List[BookingResponse])
def get_bookings():
    db = SessionLocal()
    db_bookings = db.query(Booking).all()
    db.close()
    return db_bookings

# Dummy data and model for potential future ML features (e.g., restaurant recommendation)
# This is a placeholder and not directly used by the current frontend JS
from sklearn.neighbors import KNeighborsClassifier
import numpy as np
import pandas as pd

def train_dummy_model():
    # Dummy data for demonstration
    # Features: cuisine_type (encoded), avg_rating, price_range
    # Target: user_preference (e.g., 0 for Italian, 1 for Chinese)
    data = {
        'cuisine_type': [0, 0, 1, 1, 0, 1, 0, 1],
        'avg_rating': [4.5, 4.0, 4.8, 3.5, 4.2, 4.9, 3.9, 4.1],
        'price_range': [2, 1, 3, 1, 2, 3, 1, 2],
        'user_preference': [0, 0, 1, 0, 0, 1, 0, 1]
    }
    df = pd.DataFrame(data)
    X = df[['cuisine_type', 'avg_rating', 'price_range']]
    y = df['user_preference']

    model = KNeighborsClassifier(n_neighbors=3)
    model.fit(X, y)
    return model

# Train the model on startup
dummy_ml_model = train_dummy_model()

@app.post("/api/predict_recommendation")
def predict_recommendation(cuisine_type: int, avg_rating: float, price_range: int):
    global dummy_ml_model
    prediction = dummy_ml_model.predict([[cuisine_type, avg_rating, price_range]])
    return {"recommended_preference": int(prediction[0])}

# Add a simple root endpoint for basic check
@app.get("/")
def read_root():
    return {"message": "Zwiggy Backend API is running"}
