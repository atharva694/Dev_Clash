CREATE TABLE "bookings" (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	restaurant_id INTEGER, 
	booking_time VARCHAR, 
	num_people INTEGER, 
	status VARCHAR DEFAULT 'Confirmed',
	PRIMARY KEY (id)
);
CREATE TABLE "menu_items" (
	id INTEGER NOT NULL, 
	name VARCHAR, 
	description VARCHAR, 
	price REAL, 
	restaurant_id INTEGER, 
	PRIMARY KEY (id)
);
CREATE TABLE "orders" (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	restaurant_id INTEGER, 
	items VARCHAR, 
	total_amount REAL, 
	status VARCHAR DEFAULT 'Pending',
	PRIMARY KEY (id)
);
CREATE TABLE "restaurants" (
	id INTEGER NOT NULL, 
	name VARCHAR, 
	address VARCHAR, 
	cuisine_type VARCHAR, 
	phone_number VARCHAR, 
	PRIMARY KEY (id)
);
CREATE INDEX "ix_bookings_id" ON "bookings" (id);
CREATE INDEX "ix_menu_items_id" ON "menu_items" (id);
CREATE INDEX "ix_menu_items_name" ON "menu_items" (name);
CREATE INDEX "ix_orders_id" ON "orders" (id);
CREATE INDEX "ix_restaurants_id" ON "restaurants" (id);
CREATE INDEX "ix_restaurants_name" ON "restaurants" (name);