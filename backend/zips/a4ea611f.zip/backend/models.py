from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

DATABASE_URL = "sqlite:///./app.db"

engine = create_engine(DATABASE_URL)
Base = declarative_base()

class Restaurant(Base):
    __tablename__ = "restaurants"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    address = Column(String)
    cuisine_type = Column(String)
    phone_number = Column(String)

    menu_items = relationship("MenuItem", back_populates="restaurant")
    orders = relationship("Order", back_populates="restaurant")
    bookings = relationship("Booking", back_populates="restaurant")

class MenuItem(Base):
    __tablename__ = "menu_items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String)
    price = Column(Float)
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))

    restaurant = relationship("Restaurant", back_populates="menu_items")

class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer)
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    # In a real app, 'items' would be a more structured relationship or JSON field
    items = Column(String) # Storing as JSON string for simplicity
    total_amount = Column(Float)
    status = Column(String, default="Pending")

    restaurant = relationship("Restaurant", back_populates="orders")

class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer)
    restaurant_id = Column(Integer, ForeignKey("restaurants.id"))
    booking_time = Column(String) # Storing as string for simplicity
    num_people = Column(Integer)
    status = Column(String, default="Confirmed")

    restaurant = relationship("Restaurant", back_populates="bookings")

# Create a database session local
from sqlalchemy.orm import sessionmaker
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
