document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('nav ul li');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            alert(`Navigating to ${link.textContent}... (Feature not yet implemented)`);
        });
    });

    const ctaButtons = document.querySelectorAll('main section button');
    ctaButtons.forEach(button => {
        button.addEventListener('click', () => {
            alert(`${button.textContent} clicked! (Feature not yet implemented)`);
        });
    });
});