# Generated Full-Stack App

## Setup
1. Save the backend code into two files: `main.py` and `models.py`.
2. Save the requirements into `requirements.txt`.
3. Install dependencies: `pip install -r requirements.txt`.
4. Run the FastAPI server: `uvicorn main:app --reload`.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
