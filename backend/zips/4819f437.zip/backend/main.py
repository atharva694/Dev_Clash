from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import datetime
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models

# Initialize FastAPI
app = FastAPI(title="Sentinel Spam API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
models.Base.metadata.create_all(bind=engine)

# ML Model Setup (Mock Training)
# Simple Spam/Ham Training Data
training_corpus = [
    "WINNER! You won a prize, claim now!",
    "URGENT: Your account has been suspended.",
    "Meeting scheduled for tomorrow at 10am",
    "Hey, are we still on for lunch?",
    "Get a free gift card by clicking here",
    "Please review the attached invoice",
    "Congratulations, you have been selected for a bonus",
    "Can you send me the report by EOD?",
    "Debt relief options for your credit cards",
    "I'll be home late tonight, don't wait up"
]
training_labels = [1, 1, 0, 0, 1, 0, 1, 0, 1, 0]  # 1 for Spam, 0 for Ham

vectorizer = CountVectorizer()
X_train = vectorizer.fit_transform(training_corpus)
clf = MultinomialNB()
clf.fit(X_train, training_labels)

# Pydantic Models
class AnalysisRequest(BaseModel):
    content: str

class AnalysisResult(BaseModel):
    id: Optional[int] = None
    probability: float
    verdict: str
    score: float
    timestamp: str

# Spam dictionary for frequency weighting (aligned with frontend)
spam_keywords = {
    'congratulations': 0.8, 'winner': 0.9, 'urgent': 0.7, 'act now': 0.9, 'gift card': 0.8, 
    'click here': 0.85, 'guaranteed': 0.6, 'lottery': 1.0, 'prize': 0.7, 'bonus': 0.6,
    'exclusive offer': 0.7, 'limited time': 0.5, 'cash': 0.6, 'earn money': 0.9,
    'verify your account': 0.95, 'suspended': 0.8, 'debt': 0.7, 'investment': 0.6,
    'crypto': 0.5, 'million dollars': 0.9, 'inheritance': 1.0, 'won': 0.7,
    'free': 0.4, 'viagra': 1.0, 'pharmacy': 0.8, 'no cost': 0.6, 'bank': 0.3,
    'claim': 0.7, 'password': 0.5, 'security alert': 0.6, 'login': 0.4,
    'billing': 0.4, 'overdue': 0.6, 'refund': 0.7, 'unsubscribe': 0.2
}

@app.post("/api/analyze", response_model=AnalysisResult)
def analyze_email(request: AnalysisRequest):
    text = request.content.lower()
    if not text.strip():
        raise HTTPException(status_code=400, detail="Content is empty")

    # 1. Calculation via Keyword Weights (Heuristic)
    heuristic_score = 0.0
    for keyword, weight in spam_keywords.items():
        count = text.count(keyword)
        heuristic_score += count * weight

    # 2. Calculation via ML Model
    input_vec = vectorizer.transform([text])
    ml_prob = clf.predict_proba(input_vec)[0][1] * 100

    # Combined Probability Logic
    # We mix heuristic weight with ML prediction
    heuristic_prob = min((heuristic_score / 4.0) * 100, 100)
    final_prob = round((heuristic_prob * 0.4) + (ml_prob * 0.6), 2)
    
    # Determine Verdict
    if final_prob > 70:
        verdict = "High Risk"
    elif final_prob > 30:
        verdict = "Suspicious"
    else:
        verdict = "Likely Safe"

    # Store in Database
    db = SessionLocal()
    db_record = models.EmailAnalysis(
        content=request.content,
        probability=final_prob,
        verdict=verdict,
        score=heuristic_score
    )
    db.add(db_record)
    db.commit()
    db.refresh(db_record)
    db.close()

    return AnalysisResult(
        id=db_record.id,
        probability=final_prob,
        verdict=verdict,
        score=heuristic_score,
        timestamp=db_record.created_at.isoformat()
    )

@app.get("/api/history", response_model=List[AnalysisResult])
def get_history():
    db = SessionLocal()
    records = db.query(models.EmailAnalysis).order_by(models.EmailAnalysis.id.desc()).limit(10).all()
    db.close()
    return [
        AnalysisResult(
            id=r.id,
            probability=r.probability,
            verdict=r.verdict,
            score=r.score,
            timestamp=r.created_at.isoformat()
        ) for r in records
    ]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)