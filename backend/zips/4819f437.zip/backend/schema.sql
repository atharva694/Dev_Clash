CREATE TABLE email_analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT,
    probability REAL,
    verdict TEXT,
    score REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);