const spamKeywords = {
  'congratulations': 0.8, 'winner': 0.9, 'urgent': 0.7, 'act now': 0.9, 'gift card': 0.8, 
  'click here': 0.85, 'guaranteed': 0.6, 'lottery': 1.0, 'prize': 0.7, 'bonus': 0.6,
  'exclusive offer': 0.7, 'limited time': 0.5, 'cash': 0.6, 'earn money': 0.9,
  'verify your account': 0.95, 'suspended': 0.8, 'debt': 0.7, 'investment': 0.6,
  'crypto': 0.5, 'million dollars': 0.9, 'inheritance': 1.0, 'won': 0.7,
  'free': 0.4, 'viagra': 1.0, 'pharmacy': 0.8, 'no cost': 0.6, 'bank': 0.3,
  'claim': 0.7, 'password': 0.5, 'security alert': 0.6, 'login': 0.4,
  'billing': 0.4, 'overdue': 0.6, 'refund': 0.7, 'unsubscribe': 0.2
};

const inputArea = document.getElementById('emailInput');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultsSection = document.getElementById('resultsSection');
const highlightedOutput = document.getElementById('highlightedOutput');
const scoreValue = document.getElementById('scoreValue');
const scoreCircle = document.getElementById('scoreCircle');
const verdictLabel = document.getElementById('verdictLabel');
const fileInput = document.getElementById('fileInput');
const clearBtn = document.getElementById('clearBtn');

function analyzeSpam() {
  const text = inputArea.value.trim();
  if (!text) return;

  let score = 0;
  const sortedKeys = Object.keys(spamKeywords).sort((a, b) => b.length - a.length);
  
  sortedKeys.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    const matches = text.match(regex);
    if (matches) {
      score += matches.length * spamKeywords[keyword];
    }
  });

  // Calculate probability
  let probability = Math.min(Math.round((score / 4) * 100), 100);
  if (text.length < 30 && probability > 0) probability = Math.min(probability + 15, 100);
  
  resultsSection.classList.remove('hidden');
  setTimeout(() => {
    resultsSection.classList.remove('opacity-0', 'translate-y-4');
  }, 50);

  updateGauge(probability);
  renderHighlights(text, sortedKeys);
}

function updateGauge(percent) {
  const radius = 58;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference;
  
  scoreCircle.style.strokeDashoffset = offset;
  scoreValue.innerText = `${percent}%`;

  // Clear existing color classes
  scoreCircle.classList.remove('text-indigo-500', 'text-red-500', 'text-amber-500', 'text-emerald-500');

  if (percent > 70) {
    verdictLabel.innerText = 'High Risk';
    verdictLabel.className = 'mt-2 font-bold text-lg text-red-500';
    scoreCircle.classList.add('text-red-500');
  } else if (percent > 30) {
    verdictLabel.innerText = 'Suspicious';
    verdictLabel.className = 'mt-2 font-bold text-lg text-amber-500';
    scoreCircle.classList.add('text-amber-500');
  } else {
    verdictLabel.innerText = 'Likely Safe';
    verdictLabel.className = 'mt-2 font-bold text-lg text-emerald-500';
    scoreCircle.classList.add('text-emerald-500');
  }
}

function renderHighlights(text, keys) {
  // Escape HTML first to prevent XSS
  let html = text.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  
  // Construct a single regex to avoid overlapping replacements
  const escapedKeys = keys.map(k => k.replace(/[.*+?^${}()|[\\\\]]/g, '\\$&')).join('|');
  const regex = new RegExp(`\\b(${escapedKeys})\\b`, 'gi');

  html = html.replace(regex, (match) => {
    const keyword = match.toLowerCase();
    const weight = spamKeywords[keyword] || 0.5;
    const cssClass = weight > 0.7 ? 'highlight-high' : 'highlight-medium';
    return `<span class="${cssClass}">${match}</span>`;
  });

  highlightedOutput.innerHTML = html;
}

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    inputArea.value = e.target.result;
    analyzeSpam();
  };
  reader.readAsText(file);
});

clearBtn.addEventListener('click', () => {
  inputArea.value = '';
  resultsSection.classList.add('hidden', 'opacity-0', 'translate-y-4');
});

analyzeBtn.addEventListener('click', analyzeSpam);