# Generated Full-Stack App

## Setup
1. Save the backend_main as main.py and backend_models as database.py and models.py (or combine appropriately). 2. Install dependencies: pip install -r requirements.txt. 3. Run the application: python main.py. 4. The API will be available at http://localhost:8000.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
