from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any
import sqlite3
import random
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Database setup
DATABASE_NAME = "app.db"

def get_db():
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row
    return conn

# --- SQLAlchemy Models (for demonstration, not directly used by SQLite DB functions) ---
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

SQLALCHEMY_DATABASE_URL = f"sqlite:///{DATABASE_NAME}"
e ngine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class StudentModel(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    maths = Column(Integer)
    science = Column(Integer)
    history = Column(Integer)
    english = Column(Integer)

# Create tables if they don't exist
Base.metadata.create_all(bind=engine)

# --- ML Model Setup ---
model_lr = None
poly_features = PolynomialFeatures(degree=2)

def train_mock_model():
    global model_lr
    # Generate some dummy data for training
    np.random.seed(42)
    X_train = np.random.rand(100, 4) * 100 # Features: Maths, Science, History, English scores
    # Target: A somewhat correlated 'average score'
    y_train = (X_train[:, 0] * 0.2 + X_train[:, 1] * 0.3 + X_train[:, 2] * 0.1 + X_train[:, 3] * 0.4 + np.random.randn(100) * 5).clip(0, 100)

    # Transform features for polynomial regression
    X_train_poly = poly_features.fit_transform(X_train)

    # Train a simple Linear Regression model
    model_lr = LinearRegression()
    model_lr.fit(X_train_poly, y_train)
    print("Mock ML model trained successfully.")

train_mock_model() # Train the model on startup

# --- FastAPI App Setup ---
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Models ---
class StudentBase(BaseModel):
    name: str
    maths: int
    science: int
    history: int
    english: int

class StudentCreate(StudentBase):
    pass

class Student(StudentBase):
    id: int
    average: float

    class Config:
        orm_mode = True

class AnalysisData(BaseModel):
    overall_average: float
    subject_averages: Dict[str, float]
    subject_performance_trends: List[Dict[str, Any]]

# --- Helper Functions ---
def calculate_average(student_data):
    scores = [student_data['maths'], student_data['science'], student_data['history'], student_data['english']]
    return round(sum(scores) / len(scores), 1)

def populate_database():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM students")
    if cursor.fetchone()[0] == 0:
        print("Populating database with initial data...")
        students_data = [
            {"name": f"Student {i+1}", "maths": random.randint(60, 99), "science": random.randint(60, 99), "history": random.randint(60, 99), "english": random.randint(60, 99)}
            for i in range(8)
        ]
        for s_data in students_data:
            avg = calculate_average(s_data)
            cursor.execute(
                "INSERT INTO students (name, maths, science, history, english) VALUES (?, ?, ?, ?, ?)",
                (s_data['name'], s_data['maths'], s_data['science'], s_data['history'], s_data['english'])
            )
        conn.commit()
    conn.close()

populate_database() # Populate on startup if empty

# --- API Endpoints ---
@app.get("/api/students", response_model=List[Student])
def get_students():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, maths, science, history, english FROM students")
    students_raw = cursor.fetchall()
    conn.close()

    students = []
    for row in students_raw:
        student_dict = dict(row)
        average = calculate_average(student_dict)
        students.append(Student(
            id=student_dict['id'],
            name=student_dict['name'],
            maths=student_dict['maths'],
            science=student_dict['science'],
            history=student_dict['history'],
            english=student_dict['english'],
            average=average
        ))
    return students

@app.post("/api/students", response_model=Student, status_code=201)
def create_student(student: StudentCreate):
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO students (name, maths, science, history, english) VALUES (?, ?, ?, ?, ?)",
            (student.name, student.maths, student.science, student.history, student.english)
        )
        student_id = cursor.lastrowid
        conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Student name must be unique")
    finally:
        conn.close()

    average = calculate_average(student.dict())
    return Student(
        id=student_id,
        **student.dict(),
        average=average
    )

@app.get("/api/analysis", response_model=AnalysisData)
def get_analysis():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT name, maths, science, history, english FROM students")
    students_raw = cursor.fetchall()
    conn.close()

    if not students_raw:
        return AnalysisData(overall_average=0.0, subject_averages={}, subject_performance_trends=[])

    students = [dict(row) for row in students_raw]

    # Calculate Overall Average
    all_scores = []
    for s in students:
        all_scores.extend([s['maths'], s['science'], s['history'], s['english']])
    overall_average = round(sum(all_scores) / len(all_scores), 1) if all_scores else 0.0

    # Calculate Subject Averages
    subject_averages = {
        'Maths': round(sum(s['maths'] for s in students) / len(students), 1),
        'Science': round(sum(s['science'] for s in students) / len(students), 1),
        'History': round(sum(s['history'] for s in students) / len(students), 1),
        'English': round(sum(s['english'] for s in students) / len(students), 1)
    }

    # Prepare data for Trend Chart (using student names as categories)
    subject_performance_trends = []
    student_names = [s['name'] for s in students]
    for subject in ['Maths', 'Science', 'History', 'English']:
        subject_data = {
            'name': subject,
            'data': [s[subject.lower()] for s in students]
        }
        subject_performance_trends.append(subject_data)

    return AnalysisData(
        overall_average=overall_average,
        subject_averages=subject_averages,
        subject_performance_trends=subject_performance_trends
    )

@app.post("/api/predict", response_model=Dict[str, float])
def predict_score(student_data: StudentBase):
    """Predicts a score based on the input student data using the trained ML model."""
    # Prepare the input data for the model
    # We need to ensure the input matches the training feature order and shape
    input_data = [student_data.maths, student_data.science, student_data.history, student_data.english]
    input_array = np.array([input_data])
    
    # Transform the input using the fitted polynomial features
    input_array_poly = poly_features.transform(input_array)
    
    # Make the prediction
    predicted_score = model_lr.predict(input_array_poly)[0]
    
    # Return the prediction, ensuring it's within a reasonable range
    return {"predicted_average": round(max(0, min(100, predicted_score)), 2)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
