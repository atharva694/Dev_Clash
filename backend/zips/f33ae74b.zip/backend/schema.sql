CREATE TABLE students (
	id INTEGER NOT NULL, 
	name VARCHAR NOT NULL, 
	maths INTEGER, 
	science INTEGER, 
	history INTEGER, 
	english INTEGER, 
	PRIMARY KEY (id)
);
CREATE UNIQUE INDEX idx_students_name ON students (name);
CREATE INDEX ix_students_id ON students (id);