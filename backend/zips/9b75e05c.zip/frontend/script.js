document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    if (window.scrollY > 50) {
        nav.classList.add('py-2');
        nav.classList.remove('py-4');
        nav.style.backgroundColor = 'rgba(15, 23, 42, 0.95)';
    } else {
        nav.classList.add('py-4');
        nav.classList.remove('py-2');
        nav.style.backgroundColor = 'rgba(15, 23, 42, 0.6)';
    }
});

console.log("%c Prem Jha | Backend Developer ", "background: #10b981; color: #020617; font-weight: bold; padding: 4px; border-radius: 4px;");