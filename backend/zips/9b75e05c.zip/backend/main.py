import os
import numpy as np
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from models import Base, Project, Skill, ContactMessage, engine, SessionLocal

# Initialize FastAPI
app = FastAPI(title="Prem Jha Portfolio API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create Database Tables
Base.metadata.create_all(bind=engine)

# Database Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- Pydantic Models ---
class SkillBase(BaseModel):
    name: str
    category: str
    icon: str

class SkillOut(SkillBase):
    id: int
    class Config: from_attributes = True

class ProjectBase(BaseModel):
    title: str
    description: str
    tech_stack: str
    image_url: str
    demo_link: Optional[str] = None
    github_link: Optional[str] = None

class ProjectOut(ProjectBase):
    id: int
    class Config: from_attributes = True

class ContactCreate(BaseModel):
    name: str
    email: EmailStr
    message: str

class PredictionRequest(BaseModel):
    description: str

# --- ML Mock Model ---
# A simple model that categorizes a project description into 'Backend', 'Frontend', or 'DevOps'
vectorizer = TfidfVectorizer()
clf = MultinomialNB()

def train_mock_model():
    texts = [
        "FastAPI microservice with SQLAlchemy and PostgreSQL",
        "React dashboard with Tailwind CSS and Framer Motion",
        "CI/CD pipeline with GitHub Actions and Docker containers",
        "Optimizing database queries and redis caching layers",
        "Responsive landing page with modern CSS and HTML",
        "Kubernetes orchestration and cloud infrastructure management"
    ]
    labels = ["Backend", "Frontend", "DevOps", "Backend", "Frontend", "DevOps"]
    X = vectorizer.fit_transform(texts)
    clf.fit(X, labels)

train_mock_model()

# --- Routes ---

@app.on_event("startup")
def seed_data():
    db = SessionLocal()
    if not db.query(Skill).first():
        skills = [
            Skill(name="Python", category="Backend", icon="fab fa-python"),
            Skill(name="FastAPI", category="Backend", icon="fas fa-bolt"),
            Skill(name="SQLAlchemy", category="Backend", icon="fas fa-database"),
            Skill(name="React", category="Frontend", icon="fab fa-react"),
            Skill(name="Tailwind", category="Frontend", icon="fab fa-css3")
        ]
        db.add_all(skills)
    if not db.query(Project).first():
        projects = [
            Project(
                title="E-Commerce Engine",
                description="Highly scalable backend for a multi-vendor platform using Python and Flask.",
                tech_stack="Python, Flask, SQLAlchemy, Redis",
                image_url="https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&q=80&w=800",
                github_link="https://github.com/premjha/ecommerce"
            ),
            Project(
                title="Analytics Dashboard",
                description="Real-time data visualization tool with FastAPI and WebSocket support.",
                tech_stack="FastAPI, Chart.js, SQLite",
                image_url="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
                github_link="https://github.com/premjha/analytics"
            )
        ]
        db.add_all(projects)
    db.commit()
    db.close()

@app.get("/api/skills", response_model=List[SkillOut])
def get_skills(db: Session = Depends(get_db)):
    return db.query(Skill).all()

@app.get("/api/projects", response_model=List[ProjectOut])
def get_projects(db: Session = Depends(get_db)):
    return db.query(Project).all()

@app.post("/api/contact")
def send_message(contact: ContactCreate, db: Session = Depends(get_db)):
    msg = ContactMessage(
        name=contact.name,
        email=contact.email,
        message=contact.message,
        created_at=datetime.utcnow()
    )
    db.add(msg)
    db.commit()
    return {"status": "success", "message": "Message received! Prem will get back to you soon."}

@app.post("/api/predict-category")
def predict_project_category(req: PredictionRequest):
    try:
        X = vectorizer.transform([req.description])
        prediction = clf.predict(X)[0]
        return {"category": prediction}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)