CREATE TABLE skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(50),
    category VARCHAR(50),
    icon VARCHAR(100)
);

CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(100),
    description TEXT,
    tech_stack VARCHAR(200),
    image_url VARCHAR(500),
    demo_link VARCHAR(500),
    github_link VARCHAR(500)
);

CREATE TABLE contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100),
    email VARCHAR(100),
    message TEXT,
    created_at DATETIME
);