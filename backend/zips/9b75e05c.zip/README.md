# Generated Full-Stack App

## Setup
1. Install dependencies: pip install -r requirements.txt
2. Run the application: python main.py
3. The API will be available at http://localhost:8000/api. The backend will automatically seed initial data for projects and skills on first run.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
