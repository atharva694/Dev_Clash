document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    const checkoutBtn = document.getElementById('checkout-btn');
    const checkoutSection = document.getElementById('checkout');
    const placeOrderBtn = document.getElementById('place-order-btn');
    const orderTrackingSection = document.getElementById('order-tracking');
    const menuSection = document.getElementById('menu');
    const cartSection = document.getElementById('cart');

    let cart = [];

    function updateCartDisplay() {
        cartItemsContainer.innerHTML = '';
        let total = 0;
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<li class="text-gray-400 italic">Your cart is empty.</li>';
        } else {
            cart.forEach((item, index) => {
                const listItem = document.createElement('li');
                listItem.className = 'flex justify-between items-center bg-gray-700 p-3 rounded';
                listItem.innerHTML = `
                    <span class="font-medium">${item.name}</span>
                    <span class="font-medium">₹${item.price}</span>
                    <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm remove-item" data-index="${index}">Remove</button>
                `;
                cartItemsContainer.appendChild(listItem);
                total += item.price;
            });
        }
        cartTotalElement.textContent = `₹${total}`;
    }

    document.querySelectorAll('.addToCart').forEach(button => {
        button.addEventListener('click', (e) => {
            const card = e.target.closest('.bg-gray-800');
            const name = card.querySelector('h3').textContent;
            const price = parseFloat(card.querySelector('.font-semibold.text-green-400').textContent.replace('₹', ''));
            cart.push({ name, price });
            updateCartDisplay();
            // Simple feedback
            e.target.textContent = 'Added!';
            setTimeout(() => {
                e.target.textContent = 'Add to Cart';
            }, 1500);
        });
    });

    cartItemsContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-item')) {
            const indexToRemove = parseInt(e.target.dataset.index);
            cart.splice(indexToRemove, 1);
            updateCartDisplay();
        }
    });

    checkoutBtn.addEventListener('click', () => {
        menuSection.classList.add('hidden');
        cartSection.classList.add('hidden');
        checkoutSection.classList.remove('hidden');
        checkoutBtn.classList.add('hidden');
    });

    placeOrderBtn.addEventListener('click', () => {
        const address = document.getElementById('address').value;
        if (!address.trim()) {
            alert('Please enter your delivery address.');
            return;
        }
        
        // Simulate order placement
        checkoutSection.classList.add('hidden');
        orderTrackingSection.classList.remove('hidden');
        
        // Simulate map loading and update ETA
        setTimeout(() => {
            document.getElementById('map-placeholder').innerHTML = '<p class="text-lg font-semibold">Map loaded! Your order is on its way.</p>';
            const randomMinutes = Math.floor(Math.random() * 20) + 20; // 20-40 minutes
            document.getElementById('eta').textContent = `${randomMinutes} minutes`;
        }, 2000);
    });

    updateCartDisplay(); // Initialize cart display
});
