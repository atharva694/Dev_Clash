from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from database import SessionLocal, engine, Base, Order, OrderItem, MenuItem
import random

# Create database tables if they don't exist
Base.metadata.create_all(bind=engine)

app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Models for Request/Response ---

class MenuItemCreate(BaseModel):
    name: str
    description: str
    price: float
    image_url: str

class MenuItemResponse(MenuItemCreate):
    id: int

class OrderItemCreate(BaseModel):
    menu_item_id: int
    quantity: int

class OrderItemResponse(OrderItemCreate):
    id: int
    menu_item: MenuItemResponse

class OrderCreate(BaseModel):
    items: List[OrderItemCreate]
    customer_address: str
    payment_method: str

class OrderResponse(BaseModel):
    id: int
    items: List[OrderItemResponse]
    customer_address: str
    payment_method: str
    status: str
    total_amount: float
    created_at: str

class OrderStatusUpdate(BaseModel):
    status: str

# --- Mock Data Initialization ---
def initialize_mock_data():
    db = SessionLocal()
    if db.query(MenuItem).count() == 0:
        menu_items_data = [
            MenuItem(name="Dal Makhani", description="Creamy lentil dish, slow-cooked to perfection.", price=150.0, image_url="https://via.placeholder.com/300x200/4b5563/ffffff?text=Dal+Makhani"),
            MenuItem(name="Paneer Tikka", description="Spiced cottage cheese cubes, grilled to smoky perfection.", price=180.0, image_url="https://via.placeholder.com/300x200/4b5563/ffffff?text=Paneer+Tikka"),
            MenuItem(name="Chicken Biryani", description="Aromatic rice dish with tender chicken and spices.", price=250.0, image_url="https://via.placeholder.com/300x200/4b5563/ffffff?text=Chicken+Biryani"),
            MenuItem(name="Aloo Gobi", description="A classic Indian dish of potatoes and cauliflower.", price=120.0, image_url="https://via.placeholder.com/300x200/4b5563/ffffff?text=Aloo+Gobi")
        ]
        db.add_all(menu_items_data)
        db.commit()
    db.close()

initialize_mock_data()

# --- API Endpoints ---

@app.get("/api/menu", response_model=List[MenuItemResponse])
def get_menu():
    db = SessionLocal()
    menu_items = db.query(MenuItem).all()
    db.close()
    return menu_items

@app.post("/api/orders", response_model=OrderResponse, status_code=201)
def create_order(order_data: OrderCreate):
    db = SessionLocal()
    new_order = Order(customer_address=order_data.customer_address, payment_method=order_data.payment_method, status="Pending")
    db.add(new_order)
    db.commit()
    db.refresh(new_order)

    total_amount = 0
    for item_data in order_data.items:
        menu_item = db.query(MenuItem).filter(MenuItem.id == item_data.menu_item_id).first()
        if not menu_item:
            db.rollback()
            raise HTTPException(status_code=404, detail=f"Menu item with id {item_data.menu_item_id} not found")
        
        order_item = OrderItem(
            order_id=new_order.id,
            menu_item_id=item_data.menu_item_id,
            quantity=item_data.quantity,
            price=menu_item.price * item_data.quantity # Calculate price for this item
        )
        db.add(order_item)
        total_amount += order_item.price

    new_order.total_amount = total_amount
    db.commit()
    db.refresh(new_order)

    # Fetch related items for response
    created_order = db.query(Order).filter(Order.id == new_order.id).first()
    db.close()
    return created_order

@app.get("/api/orders/{order_id}", response_model=OrderResponse)
def get_order(order_id: int):
    db = SessionLocal()
    order = db.query(Order).filter(Order.id == order_id).first()
    db.close()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@app.put("/api/orders/{order_id}/status", response_model=OrderResponse)
def update_order_status(order_id: int, status_update: OrderStatusUpdate):
    db = SessionLocal()
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        db.close()
        raise HTTPException(status_code=404, detail="Order not found")
    
    order.status = status_update.status
    db.commit()
    db.refresh(order)
    db.close()
    return order

# Mock location tracking endpoint (for demonstration)
# In a real app, this would involve more complex logic, perhaps using WebSockets or frequent polling.
# For simplicity, we'll just return a static mock location or a randomly generated one.
@app.get("/api/orders/{order_id}/location")
def get_order_location(order_id: int):
    # In a real application, you would fetch the actual live location of the delivery agent.
    # For this mock, we'll return a static or randomly generated location.
    db = SessionLocal()
    order = db.query(Order).filter(Order.id == order_id).first()
    db.close()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    # Mocking a location - replace with actual logic if needed
    mock_latitude = 18.5 + random.uniform(-0.01, 0.01) # Example coordinates near Narhe
    mock_longitude = 73.8 + random.uniform(-0.01, 0.01)

    return {
        "order_id": order_id,
        "latitude": mock_latitude,
        "longitude": mock_longitude,
        "timestamp": "2023-10-27T10:30:00Z", # Example timestamp
        "message": "Delivery agent is en route."
    }
