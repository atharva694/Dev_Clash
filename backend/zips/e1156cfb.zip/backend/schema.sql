CREATE TABLE menu_items (
  id INTEGER NOT NULL, 
  name VARCHAR, 
  description VARCHAR, 
  price REAL, 
  image_url VARCHAR, 
  PRIMARY KEY (id)
);
CREATE TABLE orders (
  id INTEGER NOT NULL, 
  customer_address VARCHAR, 
  payment_method VARCHAR, 
  status VARCHAR DEFAULT 'Pending', 
  total_amount REAL DEFAULT 0.0, 
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
  PRIMARY KEY (id)
);
CREATE TABLE order_items (
  id INTEGER NOT NULL, 
  order_id INTEGER, 
  menu_item_id INTEGER, 
  quantity INTEGER, 
  price REAL, 
  PRIMARY KEY (id),
  FOREIGN KEY(order_id) REFERENCES orders (id),
  FOREIGN KEY(menu_item_id) REFERENCES menu_items (id)
);
CREATE INDEX idx_menu_items_name ON menu_items (name);
CREATE INDEX idx_menu_items_id ON menu_items (id);
CREATE INDEX idx_orders_customer_address ON orders (customer_address);
CREATE INDEX idx_orders_id ON orders (id);
CREATE INDEX idx_orders_payment_method ON orders (payment_method);
CREATE INDEX idx_orders_status ON orders (status);
CREATE INDEX idx_order_items_id ON order_items (id);
