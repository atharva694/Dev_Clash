# Generated Full-Stack App

## Setup
1. Save the backend code as `main.py`.
2. Save the requirements as `requirements.txt`.
3. Install dependencies: `pip install -r requirements.txt`.
4. Run the backend: `uvicorn main:app --reload`.
5. Serve the `index.html` and `script.js` from a separate static file server or configure FastAPI to serve them.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
