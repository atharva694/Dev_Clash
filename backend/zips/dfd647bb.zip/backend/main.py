from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import sqlite3
import json

app = FastAPI()

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"], )

DATABASE = "app.db"

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# --- Pydantic Models ---
class TimerSettings(BaseModel):
    work_duration: int
    short_break_duration: int
    long_break_duration: int
    long_break_interval: int

class TimerState(BaseModel):
    time_left: int
    is_running: bool
    current_session_type: str
    session_count: int

# --- Database Setup ---
def setup_database():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_duration INTEGER NOT NULL,
        short_break_duration INTEGER NOT NULL,
        long_break_duration INTEGER NOT NULL,
        long_break_interval INTEGER NOT NULL
    )
    """")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timer_state (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        time_left INTEGER NOT NULL,
        is_running BOOLEAN NOT NULL,
        current_session_type TEXT NOT NULL,
        session_count INTEGER NOT NULL
    )
    """")
    conn.commit()
    conn.close()

setup_database()

# --- Helper Functions ---
def load_settings():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM settings ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    if row:
        return TimerSettings(
            work_duration=row['work_duration'],
            short_break_duration=row['short_break_duration'],
            long_break_duration=row['long_break_duration'],
            long_break_interval=row['long_break_interval']
        )
    # Default settings if none exist
    return TimerSettings(work_duration=25, short_break_duration=5, long_break_duration=10, long_break_interval=4)

def save_settings(settings: TimerSettings):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO settings (work_duration, short_break_duration, long_break_duration, long_break_interval) VALUES (?, ?, ?, ?)",
        (settings.work_duration, settings.short_break_duration, settings.long_break_duration, settings.long_break_interval)
    )
    conn.commit()
    conn.close()

def load_timer_state():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM timer_state ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    if row:
        return TimerState(
            time_left=row['time_left'],
            is_running=bool(row['is_running']),
            current_session_type=row['current_session_type'],
            session_count=row['session_count']
        )
    # Default state if none exist
    return TimerState(time_left=25*60, is_running=False, current_session_type='work', session_count=0)

def save_timer_state(state: TimerState):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO timer_state (time_left, is_running, current_session_type, session_count) VALUES (?, ?, ?, ?)",
        (state.time_left, state.is_running, state.current_session_type, state.session_count)
    )
    conn.commit()
    conn.close()

# --- API Endpoints ---
@app.get("/api/settings")
def get_settings_endpoint():
    return load_settings()

@app.post("/api/settings")
def update_settings_endpoint(settings: TimerSettings):
    save_settings(settings)
    # Reset timer state when settings are updated
    initial_settings = load_settings()
    new_state = TimerState(time_left=initial_settings.work_duration * 60, is_running=False, current_session_type='work', session_count=0)
    save_timer_state(new_state)
    return {"message": "Settings updated and timer reset"}

@app.get("/api/timer/state", response_model=TimerState)
def get_timer_state_endpoint():
    return load_timer_state()

@app.post("/api/timer/state")
def update_timer_state_endpoint(state: TimerState):
    save_timer_state(state)
    return state

@app.post("/api/timer/start")
def start_timer_endpoint():
    current_state = load_timer_state()
    current_state.is_running = True
    save_timer_state(current_state)
    return current_state

@app.post("/api/timer/pause")
def pause_timer_endpoint():
    current_state = load_timer_state()
    current_state.is_running = False
    save_timer_state(current_state)
    return current_state

@app.post("/api/timer/reset")
def reset_timer_endpoint():
    settings = load_settings()
    new_state = TimerState(time_left=settings.work_duration * 60, is_running=False, current_session_type='work', session_count=0)
    save_timer_state(new_state)
    return new_state

@app.get("/", include_in_schema=False)
def read_root():
    # This is a placeholder for serving an index.html file if you were to serve static files
    # For this example, we assume index.html is served by a separate web server or via FastAPI's static file serving.
    # To serve static files with FastAPI, you would typically use StaticFiles:
    # from fastapi.staticfiles import StaticFiles
    # app.mount("/", StaticFiles(directory="."), name="static")
    return {"message": "FastAPI backend is running. Serve your index.html separately."}
