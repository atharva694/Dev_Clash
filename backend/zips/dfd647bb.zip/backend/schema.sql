CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    work_duration INTEGER NOT NULL,
    short_break_duration INTEGER NOT NULL,
    long_break_duration INTEGER NOT NULL,
    long_break_interval INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS timer_state (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time_left INTEGER NOT NULL,
    is_running BOOLEAN NOT NULL,
    current_session_type TEXT NOT NULL,
    session_count INTEGER NOT NULL
);