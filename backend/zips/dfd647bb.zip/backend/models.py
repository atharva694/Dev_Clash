from pydantic import BaseModel

class TimerSettings(BaseModel):
    work_duration: int
    short_break_duration: int
    long_break_duration: int
    long_break_interval: int

class TimerState(BaseModel):
    time_left: int
    is_running: bool
    current_session_type: str
    session_count: int
