const timerDisplay = document.getElementById('timer-display');
const sessionInfo = document.getElementById('session-info');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const resetBtn = document.getElementById('reset-btn');
const timerEndSound = document.getElementById('timer-end-sound');
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;

const workDurationInput = document.getElementById('work-duration');
const shortBreakDurationInput = document.getElementById('short-break-duration');
const longBreakDurationInput = document.getElementById('long-break-duration');
const longBreakIntervalInput = document.getElementById('long-break-interval');

let timer;
let timeLeft;
let isRunning = false;
let currentSessionType = 'work'; // 'work', 'short-break', 'long-break'
let sessionCount = 0;
let workMinutes = 25;
let shortBreakMinutes = 5;
let longBreakMinutes = 10;
let longBreakInterval = 4;

function updateConfig() {
    workMinutes = parseInt(workDurationInput.value);
    shortBreakMinutes = parseInt(shortBreakDurationInput.value);
    longBreakMinutes = parseInt(longBreakDurationInput.value);
    longBreakInterval = parseInt(longBreakIntervalInput.value);

    if (isNaN(workMinutes) || workMinutes < 1 || workMinutes > 45) {
        workMinutes = 25;
        workDurationInput.value = 25;
    }
    if (isNaN(shortBreakMinutes) || shortBreakMinutes < 1) {
        shortBreakMinutes = 5;
        shortBreakDurationInput.value = 5;
    }
    if (isNaN(longBreakMinutes) || longBreakMinutes < 1) {
        longBreakMinutes = 10;
        longBreakDurationInput.value = 10;
    }
    if (isNaN(longBreakInterval) || longBreakInterval < 1) {
        longBreakInterval = 4;
        longBreakIntervalInput.value = 4;
    }

    resetTimer();
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function updateTimerDisplay(seconds) {
    timerDisplay.textContent = formatTime(seconds);
}

function playSound() {
    timerEndSound.play();
}

function startTimer() {
    if (isRunning) return;
    isRunning = true;
    startBtn.classList.add('hidden');
    pauseBtn.classList.remove('hidden');

    timer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay(timeLeft);

        if (timeLeft <= 0) {
            clearInterval(timer);
            isRunning = false;
            playSound();

            if (currentSessionType === 'work') {
                sessionCount++;
                if (sessionCount % longBreakInterval === 0) {
                    currentSessionType = 'long-break';
                    timeLeft = longBreakMinutes * 60;
                    sessionInfo.textContent = `Long Break ${Math.ceil(sessionCount / longBreakInterval)}/${longBreakInterval}`; 
                    body.classList.add('bg-purple-700');
                } else {
                    currentSessionType = 'short-break';
                    timeLeft = shortBreakMinutes * 60;
                    sessionInfo.textContent = `Short Break`;
                    body.classList.add('bg-blue-700');
                }
            } else {
                currentSessionType = 'work';
                timeLeft = workMinutes * 60;
                sessionInfo.textContent = `Work Session ${sessionCount + 1}`;
                body.classList.add('bg-green-700');
            }
            updateTimerDisplay(timeLeft);
            startBtn.classList.remove('hidden');
            pauseBtn.classList.add('hidden');
            body.classList.remove('bg-purple-700', 'bg-blue-700', 'bg-green-700');
            setTimeout(() => {
                if (currentSessionType === 'work') {
                    body.classList.add('bg-gray-800');
                } else if (currentSessionType === 'short-break') {
                    body.classList.add('bg-gray-700');
                } else {
                    body.classList.add('bg-gray-600');
                }
            }, 100);
            if(currentSessionType === 'work') startTimer(); 
        }
    }, 1000);
}

function pauseTimer() {
    if (!isRunning) return;
    isRunning = false;
    clearInterval(timer);
    startBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
}

function resetTimer() {
    clearInterval(timer);
    isRunning = false;
    startBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
    currentSessionType = 'work';
    sessionCount = 0;
    timeLeft = workMinutes * 60;
    updateTimerDisplay(timeLeft);
    sessionInfo.textContent = `Work Session 1`;
    body.classList.remove('bg-purple-700', 'bg-blue-700', 'bg-green-700');
    body.classList.add('bg-gray-800');
}

function toggleTheme() {
    body.classList.toggle('dark');
    body.classList.toggle('light');
    updateThemeToggleButtonText();
}

function updateThemeToggleButtonText() {
    if (body.classList.contains('dark')) {
        themeToggle.textContent = 'Switch to Light Theme';
    } else {
        themeToggle.textContent = 'Switch to Dark Theme';
    }
}

startBtn.addEventListener('click', startTimer);
pauseBtn.addEventListener('click', pauseTimer);
resetBtn.addEventListener('click', resetTimer);
themeToggle.addEventListener('click', toggleTheme);

workDurationInput.addEventListener('change', updateConfig);
shortBreakDurationInput.addEventListener('change', updateConfig);
longBreakDurationInput.addEventListener('change', updateConfig);
longBreakIntervalInput.addEventListener('change', updateConfig);

// Initial setup
updateConfig();
updateThemeToggleButtonText();
body.classList.add('bg-gray-800');

