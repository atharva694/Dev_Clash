# Generated Full-Stack App

## Setup
1. Save the backend_main content as `main.py`.
2. Save the backend_models content as `models.py`.
3. Create an empty file named `schemas.py` in the same directory as `main.py` and `models.py`, then copy the Pydantic schemas from `models.py` into `schemas.py`.
4. Save the backend_requirements content as `requirements.txt`.
5. Run `pip install -r requirements.txt`.
6. Run `python main.py` to start the FastAPI server.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
