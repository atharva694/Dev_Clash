CREATE TABLE developer_info (
    id INTEGER NOT NULL, 
    name VARCHAR NOT NULL, 
    role VARCHAR NOT NULL, 
    description TEXT NOT NULL, 
    image_url VARCHAR NOT NULL, 
    PRIMARY KEY (id)
);
CREATE INDEX ix_developer_info_id ON developer_info (id);
CREATE INDEX ix_developer_info_name ON developer_info (name);
CREATE TABLE projects (
    id INTEGER NOT NULL, 
    title VARCHAR NOT NULL, 
    description TEXT NOT NULL, 
    tech_stack TEXT NOT NULL, 
    PRIMARY KEY (id)
);
CREATE INDEX ix_projects_id ON projects (id);
CREATE INDEX ix_projects_title ON projects (title);
CREATE TABLE contact_info (
    id INTEGER NOT NULL, 
    email VARCHAR NOT NULL, 
    github_url VARCHAR, 
    linkedin_url VARCHAR, 
    PRIMARY KEY (id), 
    UNIQUE (email)
);
CREATE INDEX ix_contact_info_id ON contact_info (id);