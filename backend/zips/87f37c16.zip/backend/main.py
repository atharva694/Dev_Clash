import uvicorn
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from . import models, schemas

# Database configuration
SQLALCHEMY_DATABASE_URL = "sqlite:///./app.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Startup event to populate initial data if needed
@app.on_event("startup")
async def startup_event():
    db = SessionLocal()
    try:
        # Check if developer info exists, if not, create it
        developer_info_count = db.query(models.DeveloperInfo).count()
        if developer_info_count == 0:
            dev_info = models.DeveloperInfo(
                name="Nishant Yadav",
                role="backend developer",
                description="Architecting scalable server-side systems and robust API infrastructures. Specializing in high-performance computing and distributed architecture.",
                image_url="https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Sumatran_Elephant.jpg/640px-Sumatran_Elephant.jpg"
            )
            db.add(dev_info)
            db.commit()

        # Check if projects exist, if not, create them
        projects_count = db.query(models.Project).count()
        if projects_count == 0:
            project1 = models.Project(
                title="Jarvis",
                description="An advanced AI-driven automation backbone that integrates multiple LLM pipelines for task scheduling and system monitoring.",
                tech_stack="Python, OpenAI, Redis"
            )
            project2 = models.Project(
                title="Pinpointer",
                description="A real-time location tracking and geofencing service built for logistics, ensuring precise asset monitoring and event triggering.",
                tech_stack="Node.js, PostgreSQL, WebSockets"
            )
            db.add_all([project1, project2])
            db.commit()

        # Check if contact info exists, if not, create it
        contact_info_count = db.query(models.ContactInfo).count()
        if contact_info_count == 0:
            contact_info = models.ContactInfo(
                email="nishant.yadav@example.com", # Placeholder email
                github_url="https://github.com/nishantyadav", # Placeholder
                linkedin_url="https://linkedin.com/in/nishantyadav" # Placeholder
            )
            db.add(contact_info)
            db.commit()

    finally:
        db.close()

# API Endpoints

@app.get("/api/developer_info", response_model=schemas.DeveloperInfoResponse)
async def get_developer_info(db: Session = Depends(get_db)):
    dev_info = db.query(models.DeveloperInfo).first()
    if dev_info is None:
        raise HTTPException(status_code=404, detail="Developer info not found")
    return dev_info

@app.get("/api/projects", response_model=list[schemas.ProjectResponse])
async def get_all_projects(db: Session = Depends(get_db)):
    projects = db.query(models.Project).all()
    return projects

@app.get("/api/projects/{project_id}", response_model=schemas.ProjectResponse)
async def get_project_by_id(project_id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

@app.get("/api/contact_info", response_model=schemas.ContactInfoResponse)
async def get_contact_info(db: Session = Depends(get_db)):
    contact_info = db.query(models.ContactInfo).first()
    if contact_info is None:
        raise HTTPException(status_code=404, detail="Contact info not found")
    return contact_info

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
