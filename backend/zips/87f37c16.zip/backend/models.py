from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base
from pydantic import BaseModel
from typing import List, Optional

Base = declarative_base()

# SQLAlchemy Models
class DeveloperInfo(Base):
    __tablename__ = "developer_info"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    role = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    image_url = Column(String, nullable=False)

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True, nullable=False)
    description = Column(Text, nullable=False)
    tech_stack = Column(Text, nullable=False) # Storing as a comma-separated string for simplicity

class ContactInfo(Base):
    __tablename__ = "contact_info"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False)
    github_url = Column(String, nullable=True)
    linkedin_url = Column(String, nullable=True)

# Pydantic Schemas (for request/response validation)
class DeveloperInfoBase(BaseModel):
    name: str
    role: str
    description: str
    image_url: str

class DeveloperInfoResponse(DeveloperInfoBase):
    id: int

    class Config:
        orm_mode = True

class ProjectBase(BaseModel):
    title: str
    description: str
    tech_stack: str # Will be treated as a single string, e.g., "Python, FastAPI, SQL"

class ProjectCreate(ProjectBase):
    pass

class ProjectResponse(ProjectBase):
    id: int

    class Config:
        orm_mode = True

class ContactInfoBase(BaseModel):
    email: str
    github_url: Optional[str] = None
    linkedin_url: Optional[str] = None

class ContactInfoCreate(ContactInfoBase):
    pass

class ContactInfoResponse(ContactInfoBase):
    id: int

    class Config:
        orm_mode = True
