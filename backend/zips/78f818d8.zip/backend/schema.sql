CREATE TABLE IF NOT EXISTS analysis_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_name TEXT NOT NULL,
    ats_score INTEGER,
    identified_skills TEXT,
    experience_summary TEXT,
    raw_text TEXT
);
