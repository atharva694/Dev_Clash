from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import sqlite3
import os
import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

# Define database path
DATABASE_PATH = 'app.db'

# --- Database Setup ---

def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not os.path.exists(DATABASE_PATH):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS analysis_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_name TEXT NOT NULL,
                ats_score INTEGER,
                identified_skills TEXT,
                experience_summary TEXT,
                raw_text TEXT
            )
        ''')
        conn.commit()
        conn.close()

# --- Pydantic Models ---

class AnalysisResult(BaseModel):
    file_name: str
    ats_score: int
    identified_skills: List[str]
    experience_summary: str
    keyword_match_percentage: int

class AnalysisResponse(AnalysisResult):
    class Config:
        orm_mode = True

# --- ML Model Setup ---

# Dummy data for ML model (replace with actual resume text if available)
# In a real scenario, this would be trained on a dataset of resumes and job descriptions.
# For this mock, we'll just create a simple TF-IDF vectorizer and a basic lookup.

resume_data = [
    "Software Engineer with 5 years of experience in Python, Java, and C++. Skilled in developing scalable web applications using Django and Flask. Experience with cloud platforms like AWS and Azure. Strong understanding of SQL and NoSQL databases.",
    "Data Scientist with expertise in machine learning, statistical modeling, and data visualization. Proficient in Python (scikit-learn, pandas, numpy) and R. Experience in building predictive models and analyzing large datasets. Familiar with big data technologies like Spark.",
    "Frontend Developer specializing in JavaScript, React, and Vue.js. Experienced in building responsive and interactive user interfaces. Knowledge of HTML, CSS, and modern frontend build tools. Passionate about creating user-centric designs.",
    "Project Manager with a proven track record of delivering complex projects on time and within budget. Skilled in Agile methodologies, Scrum, and Waterfall. Experience in leading cross-functional teams and stakeholder management.",
    "DevOps Engineer with extensive experience in CI/CD pipelines, automation, and infrastructure management. Proficient in Docker, Kubernetes, Jenkins, and Terraform. Cloud expertise in AWS and GCP."
]

# Define target keywords that a resume might be scored against
TARGET_KEYWORDS = [
    "Python", "Java", "C++", "Django", "Flask", "AWS", "Azure", "SQL", "NoSQL",
    "Machine Learning", "Data Science", "Statistical Modeling", "Data Visualization",
    "R", "Spark", "JavaScript", "React", "Vue.js", "HTML", "CSS",
    "Project Management", "Agile", "Scrum", "DevOps", "CI/CD", "Docker", "Kubernetes", "Terraform", "GCP"
]

v = TfidfVectorizer()
tfidf_matrix = v.fit_transform(resume_data)

knn_model = NearestNeighbors(n_neighbors=2, algorithm='brute')
knn_model.fit(tfidf_matrix)

def extract_skills_from_text(text):
    found_skills = set()
    # Simple keyword matching, can be enhanced with NLP techniques
    for keyword in TARGET_KEYWORDS:
        if re.search(r'\b' + re.escape(keyword) + r'\b', text, re.IGNORECASE):
            found_skills.add(keyword)
    return sorted(list(found_skills))

def calculate_ats_score(identified_skills, total_target_keywords):
    if not total_target_keywords: return 0
    match_count = len(identified_skills)
    # A very basic scoring: percentage of matched target keywords
    score = (match_count / total_target_keywords) * 100
    # Add a small random factor to simulate variability
    score += np.random.uniform(-5, 5)
    return max(0, min(100, int(score)))

def generate_experience_summary(identified_skills, text):
    # Very basic summary generation
    if not identified_skills:
        return "No specific skills identified for summary."
    summary_parts = []
    if "Python" in identified_skills or "Django" in identified_skills or "Flask" in identified_skills:
        summary_parts.append("Python development (web applications)")
    if "JavaScript" in identified_skills or "React" in identified_skills or "Vue.js" in identified_skills:
        summary_parts.append("Frontend development (JavaScript frameworks)")
    if "AWS" in identified_skills or "Azure" in identified_skills or "GCP" in identified_skills:
        summary_parts.append("Cloud services (AWS, Azure, GCP)")
    if "SQL" in identified_skills or "NoSQL" in identified_skills:
        summary_parts.append("Database management")
    if "Machine Learning" in identified_skills or "Data Science" in identified_skills:
        summary_parts.append("Data science and machine learning")
    if "Project Management" in identified_skills or "Agile" in identified_skills:
        summary_parts.append("Project management (Agile)")
    if "DevOps" in identified_skills or "Docker" in identified_skills or "Kubernetes" in identified_skills:
        summary_parts.append("DevOps and containerization")

    if not summary_parts:
        # Fallback if no specific patterns matched, use top skills
        return f"Experience likely includes skills such as: {', '.join(identified_skills[:3])}."

    return "Experience focused on: " + ", ".join(summary_parts) + "."


# --- FastAPI App ---

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post('/api/analyze_resume', response_model=AnalysisResponse)
async def analyze_resume(resume: UploadFile = File(...)):
    if resume.content_type != 'application/pdf':
        raise HTTPException(status_code=400, detail='Invalid file type. Please upload a PDF.')

    try:
        # Read the file content
        contents = await resume.read()

        # --- Mock Analysis Logic ---
        # In a real application, you would use a PDF parsing library (e.g., PyMuPDF, pdfminer.six)
        # to extract text. For this example, we'll use the filename and simulate text extraction.
        # This part needs a proper PDF text extraction implementation.
        # For demonstration, we'll pretend we extracted text from the file.
        # Let's mock the extracted text based on keywords present in the filename or a generic string.

        mock_extracted_text = f"Resume for {resume.filename}. "
        for keyword in TARGET_KEYWORDS:
            if keyword.lower() in resume.filename.lower():
                mock_extracted_text += f"{keyword} 
"

        # If no keywords found in filename, use a generic placeholder text
        if len(mock_extracted_text.split()) < 5: # Arbitrary check for minimal content
            mock_extracted_text += "This is a sample resume text. It contains information about software development, data analysis, and project management. The candidate has skills in Python, Java, SQL, and cloud technologies."

        identified_skills = extract_skills_from_text(mock_extracted_text)
        total_target_keywords = len(TARGET_KEYWORDS)
        ats_score = calculate_ats_score(identified_skills, total_target_keywords)
        experience_summary = generate_experience_summary(identified_skills, mock_extracted_text)
        keyword_match_percentage = int((len(identified_skills) / total_target_keywords) * 100) if total_target_keywords else 0

        result = AnalysisResult(
            file_name=resume.filename,
            ats_score=ats_score,
            identified_skills=identified_skills,
            experience_summary=experience_summary,
            keyword_match_percentage=keyword_match_percentage
        )

        # --- Store in Database ---
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            