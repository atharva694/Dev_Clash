from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "sqlite:///./app.db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class AnalysisResultDB(Base):
    __tablename__ = "analysis_results"

    id = Column(Integer, primary_key=True, index=True)
    file_name = Column(String, index=True)
    ats_score = Column(Integer)
    identified_skills = Column(String) # Store as JSON string or comma-separated
    experience_summary = Column(String)
    raw_text = Column(String) # Optional: store the extracted raw text

# Create tables if they don't exist
Base.metadata.create_all(bind=engine)
