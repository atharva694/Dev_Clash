document.getElementById('resume-upload').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        uploadResume(file);
    }
});

async function uploadResume(file) {
    const formData = new FormData();
    formData.append('resume', file);

    // In a real application, you would send this to a backend server.
    // For this example, we'll simulate the analysis and results.
    console.log('Simulating resume upload and analysis for:', file.name);

    displayLoadingState();

    // Simulate network delay and analysis
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Simulate analysis results
    const analysisResults = simulateAnalysis(file);

    displayResults(analysisResults);
}

function simulateAnalysis(file) {
    // This is a placeholder for actual resume parsing and analysis.
    // In a real-world scenario, you'd use libraries like pdf-parse, natural language processing (NLP) tools,
    // and potentially integrate with an ATS screening service or custom algorithms.

    const keywords = ['JavaScript', 'React', 'Node.js', 'Python', 'AWS', 'Agile', 'SQL', 'API'];
    const skillsFound = keywords.filter(skill => file.name.toLowerCase().includes(skill.toLowerCase()) || Math.random() > 0.5);
    const totalKeywords = keywords.length;
    const matchedKeywords = skillsFound.length;

    // Simulate ATS score (e.g., based on keyword match density)
    const atsScore = Math.min(100, Math.round((matchedKeywords / totalKeywords) * 100) + Math.floor(Math.random() * 10));

    // Simulate experience summary
    const experienceSummary = "This resume likely details experience in " + skillsFound.slice(0, 3).join(', ') + ". Further analysis needed for detailed summary.";

    return {
        fileName: file.name,
        atsScore: atsScore,
        identifiedSkills: skillsFound,
        experienceSummary: experienceSummary,
        keywordMatchPercentage: Math.round((matchedKeywords / totalKeywords) * 100)
    };
}

function displayLoadingState() {
    const resultsSection = document.getElementById('results-section');
    const outputDiv = document.getElementById('analysis-output');
    outputDiv.innerHTML = '<div class="text-center"><div class="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-teal-400 mx-auto mb-4"></div><p class="text-lg">Analyzing your resume...</p></div>';
    resultsSection.classList.remove('hidden');
}

function displayResults(results) {
    const outputDiv = document.getElementById('analysis-output');
    const progressBarWidth = results.atsScore;

    outputDiv.innerHTML = `
        <div class="mb-6 p-4 card rounded-lg">
            <h3 class="text-xl font-semibold mb-3">Overall Score</h3>
            <div class="progress-bar-container rounded-full h-3 mb-2">
                <div class="progress-bar rounded-full h-3" style="width: ${progressBarWidth}%;"></div>
            </div>
            <p class="text-center text-lg font-bold ${results.atsScore < 50 ? 'text-red-500' : 'text-teal-400'}">${results.atsScore}%</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="p-4 card rounded-lg">
                <h3 class="text-xl font-semibold mb-3">Identified Skills</h3>
                ${results.identifiedSkills.length > 0 ? results.identifiedSkills.map(skill => `<span class="inline-block bg-gray-700 text-teal-300 text-sm font-medium mr-2 mb-2 px-2.5 py-0.5 rounded">${skill}</span>`).join('') : '<p class="text-gray-500">No specific skills identified.</p>'}
            </div>
            <div class="p-4 card rounded-lg">
                <h3 class="text-xl font-semibold mb-3">Keyword Match</h3>
                <p class="text-lg">${results.keywordMatchPercentage}%</p>
                <p class="text-sm text-gray-400">Based on a predefined set of common job keywords.</p>
            </div>
        </div>

        <div class="p-4 card rounded-lg">
            <h3 class="text-xl font-semibold mb-3">Experience Summary</h3>
            <p class="text-gray-300 leading-relaxed">${results.experienceSummary}</p>
        </div>
    `;
}
