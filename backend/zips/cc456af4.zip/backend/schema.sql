CREATE TABLE profiles (
id INTEGER NOT NULL,
name VARCHAR,
about VARCHAR,
email VARCHAR UNIQUE,
profile_pic_url VARCHAR,
PRIMARY KEY (id)
);
CREATE INDEX ix_profiles_id ON profiles (id);
CREATE INDEX ix_profiles_name ON profiles (name);
CREATE INDEX ix_profiles_email ON profiles (email);

CREATE TABLE projects (
id INTEGER NOT NULL,
title VARCHAR,
description VARCHAR,
project_url VARCHAR,
PRIMARY KEY (id)
);
CREATE INDEX ix_projects_id ON projects (id);
CREATE INDEX ix_projects_title ON projects (title);

CREATE TABLE skills (
id INTEGER NOT NULL,
name VARCHAR UNIQUE,
icon_url VARCHAR,
PRIMARY KEY (id)
);
CREATE INDEX ix_skills_id ON skills (id);
CREATE INDEX ix_skills_name ON skills (name);