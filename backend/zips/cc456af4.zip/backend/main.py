import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from .models import Base, Profile, Project, Skill, ProfileResponse, ProjectResponse, SkillResponse

# Database configuration
SQLALCHEMY_DATABASE_URL = "sqlite:///./app.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create database tables if they don't exist
Base.metadata.create_all(bind=engine)

app = FastAPI()

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allows all origins
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods
    allow_headers=["*"], # Allows all headers
)

# Dependency to get the DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Startup event to populate initial data
@app.on_event("startup")
def startup_event():
    db = SessionLocal()
    try:
        # Populate Profile if empty
        if db.query(Profile).count() == 0:
            om_jare_profile = Profile(
                name="Om Jare",
                about="Hello! I'm Om Jare, a passionate developer with a keen interest in building robust and user-friendly applications. I specialize in backend development and enjoy tackling complex challenges with elegant solutions.",
                email="omjare@gmail.com",
                profile_pic_url="https://img.getimg.ai/images/2024-06-17/a9d18548-024e-40b6-9990-a1f09a720d3d.jpg"
            )
            db.add(om_jare_profile)
            db.commit()
            db.refresh(om_jare_profile)

        # Populate Projects if empty
        if db.query(Project).count() == 0:
            zerodha_clone = Project(
                title="Zerodha Clone",
                description="A detailed clone of the popular stock trading platform Zerodha, focusing on replicating its core functionalities and user interface for a seamless trading experience.",
                project_url="#" # Placeholder, as per frontend
            )
            db.add(zerodha_clone)
            db.commit()
            db.refresh(zerodha_clone)

        # Populate Skills if empty
        if db.query(Skill).count() == 0:
            python_skill = Skill(
                name="Python",
                icon_url="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg"
            )
            db.add(python_skill)
            db.commit()
            db.refresh(python_skill)

    finally:
        db.close()

# --- API Endpoints ---

@app.get("/api/profile", response_model=ProfileResponse)
def get_profile(db: Session = Depends(get_db)):
    profile = db.query(Profile).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@app.get("/api/projects", response_model=list[ProjectResponse])
def get_projects(db: Session = Depends(get_db)):
    projects = db.query(Project).all()
    return projects

@app.get("/api/skills", response_model=list[SkillResponse])
def get_skills(db: Session = Depends(get_db)):
    skills = db.query(Skill).all()
    return skills
