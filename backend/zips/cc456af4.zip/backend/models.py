from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from pydantic import BaseModel

Base = declarative_base()

class Profile(Base):
    __tablename__ = "profiles"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    about = Column(String)
    email = Column(String, unique=True, index=True)
    profile_pic_url = Column(String)

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    project_url = Column(String, nullable=True)

class Skill(Base):
    __tablename__ = "skills"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    icon_url = Column(String)

# Pydantic models for request/response
class ProfileBase(BaseModel):
    name: str
    about: str
    email: str
    profile_pic_url: str

class ProfileResponse(ProfileBase):
    id: int
    class Config:
        from_attributes = True

class ProjectBase(BaseModel):
    title: str
    description: str
    project_url: str | None = None

class ProjectResponse(ProjectBase):
    id: int
    class Config:
        from_attributes = True

class SkillBase(BaseModel):
    name: str
    icon_url: str

class SkillResponse(SkillBase):
    id: int
    class Config:
        from_attributes = True
