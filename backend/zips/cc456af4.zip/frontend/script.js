document.querySelectorAll('a[href^="#"]').forEach(anchor => {anchor.addEventListener('click', function (e) {e.preventDefault();const targetElement = document.querySelector(this.getAttribute('href'));if (targetElement) {targetElement.scrollIntoView({behavior: 'smooth', block: 'start'});}});});

// Basic animation for elements on scroll (optional)
const observerOptions = {
  root: null,
  rootMargin: '0px',
  threshold: 0.1
};

const observerCallback = (entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('animate-fade-in');
      entry.target.classList.remove('opacity-0');
      observer.unobserve(entry.target);
    }
  });
};

const observer = new IntersectionObserver(observerCallback, observerOptions);

document.querySelectorAll('section > div > h2, section > div > div, .grid > div').forEach(element => {
  element.classList.add('opacity-0', 'transition-opacity', 'duration-700');
  observer.observe(element);
});
