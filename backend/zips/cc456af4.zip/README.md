# Generated Full-Stack App

## Setup
1. Save the backend_main content as `main.py`.
2. Save the backend_models content as `models.py` in the same directory.
3. Save the backend_requirements content as `requirements.txt`.
4. Run `pip install -r requirements.txt`.
5. Run `python -m uvicorn main:app --reload` to start the backend server.

## Structure
```
frontend/
  index.html     - Open in browser
  style.css
  script.js

backend/
  main.py        - FastAPI server (run this)
  models.py      - SQLAlchemy + SQLite models
  requirements.txt
  schema.sql     - DB schema reference
```

## Quick Start
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Then open frontend/index.html in your browser.
