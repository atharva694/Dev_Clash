from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.orm import sessionmaker, declarative_base
import os

# --- Database Setup ---
DATABASE_URL = "sqlite:///./app.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# --- SQLAlchemy Models ---
class DbProject(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    project_url = Column(String, nullable=True)
    image_url = Column(String, nullable=True)

# Create tables
Base.metadata.create_all(bind=engine)

# --- Pydantic Models ---
class Project(BaseModel):
    id: int
    title: str
    description: str
    project_url: Optional[str] = None
    image_url: Optional[str] = None

    class Config:
        orm_mode = True

class ProjectCreate(BaseModel):
    title: str
    description: str
    project_url: Optional[str] = None
    image_url: Optional[str] = None

# --- FastAPI App ---
app = FastAPI()

# --- CORS Middleware ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] , # Allows all origins
    allow_credentials=True,
    allow_methods=["*"] , # Allows all methods
    allow_headers=["*"] , # Allows all headers
)

# --- Helper Functions ---
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- API Endpoints ---
@app.get("/api/projects", response_model=List[Project])
def get_projects(db = Depends(get_db)):
    projects = db.query(DbProject).all()
    return projects

@app.post("/api/projects", response_model=Project)
def create_project(project: ProjectCreate, db = Depends(get_db)):
    db_project = DbProject(**project.dict())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project

@app.get("/api/contact", response_model=dict)
def get_contact_info():
    return {"email": "om123@gmail.com"}

# --- Mock Data Initialization ---
@app.on_event("startup")
def startup_event():
    db = SessionLocal()
    # Add a default project if none exist
    if db.query(DbProject).count() == 0:
        sample_project = DbProject(
            title="Zerodha Clone Application",
            description="A feature-rich web application meticulously developed to mimic the core functionalities and user interface of Zerodha, a leading stock brokerage platform. This project demonstrates proficiency in building complex financial interfaces, real-time data handling, and robust backend integration.",
            project_url="#", # Placeholder URL, can be updated
            image_url="https://via.placeholder.com/300x200.png?text=Zerodha+Clone"
        )
        db.add(sample_project)
        db.commit()
    db.close()

# --- Root Endpoint for Health Check ---
@app.get("/api/")
def read_root():
    return {"message": "Portfolio API is running"}