CREATE TABLE projects (
  id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
  title VARCHAR, 
  description TEXT, 
  project_url VARCHAR, 
  image_url VARCHAR
);
CREATE INDEX ix_projects_id ON projects (id);
CREATE INDEX ix_projects_title ON projects (title);